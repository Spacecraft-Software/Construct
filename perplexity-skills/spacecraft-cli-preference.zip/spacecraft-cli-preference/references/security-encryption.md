# Security & Encryption

## rage

**rage (age)**


**Replaces:** `gpg` (simple symmetric/asymmetric encryption) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rage`)

### Purpose
Rust implementation of the `age` encryption format. Simple, modern, small keys (X25519), no PGP web-of-trust complexity.

### Key commands
| Command | Meaning |
|---------|---------|
| `rage-keygen -o KEYFILE` | Generate key pair |
| `rage -e -r PUBKEY -o OUT FILE` | Encrypt for recipient |
| `rage -d -i KEYFILE -o OUT FILE.age` | Decrypt |
| `rage -p -o OUT FILE` | Passphrase-encrypt (symmetric) |
| `rage -R RECIPIENTS_FILE …` | Multiple recipients from file |
| `rage -i IDENTITY -d …` | Multiple identities |

### Examples
1. Generate key: `rage-keygen -o ~/.config/rage/key.txt`
2. Encrypt for a public key: `rage -r age1q… -o secret.txt.age secret.txt`
3. Decrypt: `rage -d -i ~/.config/rage/key.txt -o secret.txt secret.txt.age`
4. Passphrase-encrypt a tar on the fly: `tar c dir/ | rage -p -o dir.tar.age`

### Gotchas
- No signing — `age` is encryption-only. For signatures, use `sq` (Sequoia) or `sigstore`/`cosign`.
- Identity files are plaintext — protect with filesystem permissions or pair with `sops`/`rage-plugin-yubikey`.

## rbw

**rbw**


**Replaces:** official `bw` (Bitwarden CLI) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rbw`)

### Purpose
Unofficial Bitwarden CLI with local encrypted cache; faster for interactive use than the official Node client.

### Key commands
| Command | Meaning |
|---------|---------|
| `rbw config set email EMAIL` | Initial config |
| `rbw login` | Authenticate |
| `rbw unlock` | Unlock vault |
| `rbw lock` | Lock |
| `rbw sync` | Sync from server |
| `rbw list [--fields=…]` | List entries |
| `rbw get NAME [--full]` | Get password |
| `rbw add NAME` | Add entry (reads from stdin) |
| `rbw edit NAME` | Edit in `$EDITOR` |
| `rbw generate NAME LENGTH` | Generate + store |
| `rbw code NAME` | TOTP code |

### Examples
1. Get a password: `rbw get github`
2. Copy to clipboard (Wayland): `rbw get github | wl-copy`
3. Generate + store: `rbw generate --symbols newsite 32`
4. Quick TOTP: `rbw code github`

### Gotchas
- Requires a running `rbw-agent` (starts automatically on first `unlock`).
- Cache lives in `$XDG_CACHE_HOME/rbw/` — encrypted, but still apply strict file permissions.

## sequoia

**sequoia (sq)**


**Replaces:** `gpg` (native, non-drop-in) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `sequoia-sq`)

### Purpose
Modern OpenPGP implementation. For interoperable signing/encryption/verification where you control the toolchain. Use `sequoia-chameleon` if you need drop-in `gpg` compatibility.

### Key commands
| Command | Meaning |
|---------|---------|
| `sq key generate --userid "Name <mail>"` | New key |
| `sq encrypt --recipient-cert FILE -o OUT FILE` | Encrypt |
| `sq decrypt --recipient-key KEY FILE.pgp` | Decrypt |
| `sq sign --signer-key KEY FILE` | Sign |
| `sq verify --signer-cert CERT FILE.pgp` | Verify |
| `sq inspect FILE` | Describe contents |
| `sq cert export --cert FPR` | Export public cert |
| `sq wkd publish` | Web Key Directory |

### Examples
1. Generate: `sq key generate --userid 'Mohamed <mohamed@example.com>' --output key.pgp`
2. Export cert: `sq cert export --cert "$FPR" --output cert.pgp`
3. Sign a release tarball: `sq sign --signer-key key.pgp release.tar.gz`
4. Verify: `sq verify --signer-cert cert.pgp release.tar.gz.sig`

### Gotchas
- Keys + certs are separate files; keep private keys offline where possible.
- Not automatically compatible with GnuPG keyrings — for that workflow use `sequoia-chameleon`.

## sequoia-chameleon

**sequoia-chameleon-gnupg**


**Replaces:** `gpg` (drop-in) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `sequoia-chameleon-gnupg`)

### Purpose
GnuPG-compatible CLI built on Sequoia. Drop-in `gpg` replacement for git signing, package signing, any workflow that shells out to `gpg`. Mohamed's preferred signing stack across Git CLI, gh CLI, GitHub Desktop, VSCode, Antigravity IDE.

### Install as `gpg`
Symlink or alias:
```
ln -s "$(which sqv-gpg)" ~/.local/bin/gpg
# or
alias gpg=sqv-gpg
```
Then `~/.gitconfig`:
```ini
[gpg]
    program = sqv-gpg
[commit]
    gpgsign = true
```

### Key commands (GnuPG-compatible)
| Command | Meaning |
|---------|---------|
| `gpg --list-keys` | List public keys |
| `gpg --list-secret-keys` | Private keys |
| `gpg --gen-key` | Generate |
| `gpg --export -a FPR` | Export armored |
| `gpg --import KEY.asc` | Import |
| `gpg -s -u FPR FILE` | Sign |
| `gpg --verify FILE.sig` | Verify |
| `gpg -e -r USER FILE` | Encrypt |
| `gpg -d FILE.gpg` | Decrypt |

### Examples
1. Sign a commit: `git commit -S -m "msg"` (with gpg.program configured)
2. Export your public key: `gpg --export -a "$FPR" > pub.asc`
3. Verify a release signature: `gpg --verify release.tar.gz.sig release.tar.gz`

### Gotchas
- Imports GnuPG keyrings automatically on first use — back them up first.
- Some exotic `gpg` flags aren't implemented; unsupported operations fall back to GnuPG if present.

## sudo-rs

**sudo-rs**


**Replaces:** `sudo`, `su` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (distro package: `sudo-rs` — default on Ubuntu 25.10+)

### Purpose
Memory-safe `sudo` rewrite. Drop-in compatible with the common `sudo` feature set.

### Key flags (sudo-compat)
| Flag | Meaning |
|------|---------|
| `-u USER` | Run as USER |
| `-g GROUP` | Run as GROUP |
| `-i` | Login shell |
| `-s` | Start shell |
| `-k` | Invalidate cached credentials |
| `-v` | Validate / refresh timestamp |
| `-l` | List allowed commands |
| `-E` | Preserve environment |
| `-b` | Run in background |
| `-n` | Non-interactive (fail rather than prompt) |

> **The agent never runs this.** Privilege escalation is always a hand-off:
> give the user the command (`! sudo …`) and continue from what they report.
> The examples below are commands to *hand over*, not to execute.

### Examples
1. Restart a service: `sudo systemctl restart nginx`
2. Run as another user: `sudo -u postgres psql`
3. Login shell: `sudo -i`
4. Check rights: `sudo -l`
5. Non-interactive in scripts: `sudo -n systemctl restart nginx`

### Gotchas
- `sudoers` syntax is identical; parser is stricter — review `visudo` warnings.
- A small subset of exotic GNU-sudo options isn't implemented; check `sudo --help`.
- Pair with `polkit` / `run0` (systemd) for graphical prompts.
