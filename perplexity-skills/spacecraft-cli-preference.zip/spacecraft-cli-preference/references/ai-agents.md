# AI Agents & Coding CLIs

## aichat

**aichat**


**Replaces:** multiple per-vendor LLM CLIs | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `aichat`)

### Purpose
Universal LLM REPL + CLI. One tool for OpenAI, Claude, Gemini, local Ollama, llama.cpp, Azure, Bedrock, and more. Supports RAG, agents, function-calling.

### Key commands / flags
| Command | Meaning |
|---------|---------|
| `aichat` | Start REPL |
| `aichat "PROMPT"` | One-shot |
| `-m MODEL` | Model override (e.g. `claude:claude-opus-4-7`) |
| `-r ROLE` | Predefined role (see `aichat --list-roles`) |
| `-s SESSION` | Named session |
| `-f FILE` | Attach file(s) |
| `-e` / `--execute` | Generate shell command from prompt |
| `-c` / `--code` | Output code only, no prose |
| `--rag NAME` | Use RAG collection |
| `--info` | Print config |

### REPL slash-commands
| Command | Meaning |
|---------|---------|
| `.model NAME` | Switch model |
| `.role NAME` | Activate role |
| `.session NAME` | Named session |
| `.file FILE` | Attach file |
| `.set KEY VALUE` | Runtime setting |
| `.exit` | Quit |

### Examples
1. Ask a one-off: `aichat "explain AV1 encoding tradeoffs"`
2. Generate a shell command safely: `aichat -e "find all files larger than 100MB modified today"`
3. Code-only output: `aichat -c "rust function that returns CPU count"`
4. Multi-provider switching: `aichat -m ollama:llama3.1 "summarise this diff" -f patch.diff`
5. RAG over docs: build a collection with `aichat --rag spacecraft-docs build PATH`, then `aichat --rag spacecraft-docs "question"`.

### Gotchas
- Config: `$AICHAT_CONFIG_DIR` or `~/.config/aichat/config.yaml` — holds API keys.
- `-e` executes shell commands without sandboxing — review before running.

## claude-code

**claude-code (Claude Code)**


**Replaces:** other AI coding agents | **Language:** ⚠️ TypeScript | **Install:** via `spacecraft-missing-pkg` (npm package: `@anthropic-ai/claude-code` (Node.js 18+))

### Purpose
Anthropic's official command-line coding agent. Reads/edits/runs code in your terminal with MCP server integration. **Mohamed's primary agent; elevated role in the clean-room multi-agent pipeline.**

### Launch
```
claude                    # start interactive session in $PWD
claude "<prompt>"         # one-shot
claude -p "<prompt>"      # print-mode non-interactive
claude --resume           # resume previous session
claude --continue         # continue last session
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-p` / `--print` | Non-interactive single turn |
| `--resume` | Pick a session from history |
| `--continue` | Continue most recent |
| `--model NAME` | Override model (e.g. `claude-opus-4-7`) |
| `--add-dir PATH` | Grant access to directory outside cwd |
| `--mcp-config FILE` | Load MCP servers from file |
| `--permission-mode MODE` | `default`, `acceptEdits`, `bypassPermissions`, `plan` |
| `--verbose` | Extra debug output |

### Slash commands (inside session)
| Command | Meaning |
|---------|---------|
| `/help` | List commands |
| `/clear` | Reset conversation |
| `/model` | Switch model |
| `/mcp` | Manage MCP servers |
| `/permissions` | Permission settings |
| `/cost` | Token usage |
| `/compact` | Compact transcript |
| `/exit` | Quit |

### Examples
1. Start in repo: `cd ~/code/ferrocast && claude`
2. One-shot code review: `claude -p "review the last commit and flag any unsafe blocks"`
3. Pipe into another tool: `claude -p "summarise this crate" < README.md`
4. With MCP config: `claude --mcp-config ~/.mcp.json`
5. Plan mode (no edits): `claude --permission-mode plan`

### Gotchas
- Needs Node.js 18+ and a `~/.claude.json` login.
- MCP servers in `.mcp.json` at repo root are auto-loaded (matches Mohamed's Antigravity MCP hub setup).
- When scripting, always use `-p` and inspect exit code; interactive mode doesn't play well in CI.

## codex

**codex (OpenAI Codex CLI)**


**Replaces:** manual OpenAI API calls | **Language:** ⚠️ TypeScript | **Install:** via `spacecraft-missing-pkg` (npm package: `@openai/codex`)

### Purpose
OpenAI's official local coding agent with MCP support. Slot in Mohamed's clean-room pipeline as the ChatGPT Pro / Codex agent.

### Launch
```
codex                   # REPL
codex "<prompt>"        # one-shot
codex --resume          # resume session
```

### Key flags
| Flag | Meaning |
|------|---------|
| `--model NAME` | Model override |
| `--mcp-config FILE` | MCP servers |
| `--approval-policy MODE` | Edit / exec approval behaviour |
| `--cwd PATH` | Working directory |
| `-p` / `--print` | Non-interactive |

### Examples
1. Interactive in repo: `codex`
2. Non-interactive: `codex -p "find all TODO comments and convert to GitHub issues"`
3. With MCP: `codex --mcp-config ~/.mcp.json`

### Gotchas
- Needs `OPENAI_API_KEY` (or ChatGPT Pro auth flow).
- Approval-policy choice is critical for unattended runs — `never` auto-approves, which is dangerous.

## gemini-cli

**gemini-cli (gemini)**


**Replaces:** Gemini via browser | **Language:** 🦀 Rust (or official TypeScript variant) | **Install:** via `spacecraft-missing-pkg` (upstream crate: `gemini-cli`; npm package: `@google/gemini-cli`)

### Purpose
Command-line client for Google Gemini. Mohamed uses it within the Antigravity IDE and as a pipeline model for Nix config work.

### Key commands
| Command | Meaning |
|---------|---------|
| `gemini` | Interactive chat |
| `gemini "PROMPT"` | One-shot |
| `gemini -m MODEL` | Model (`gemini-2.5-pro`, `gemini-2.5-flash`) |
| `gemini -f FILE` | Attach file |
| `gemini auth login` | OAuth / API key setup |
| `gemini --mcp-config FILE` | MCP servers |

### Examples
1. One-shot: `gemini "explain this flake.nix" < flake.nix`
2. Code review: `git diff | gemini -m gemini-2.5-pro "review"`
3. With file attachment: `gemini -f design.pdf "summarise the architecture"`

### Gotchas
- Two distinct clients share the `gemini` name; check `gemini --version` to know which is installed.
- The official Google CLI needs Google Cloud credentials; the third-party Rust one uses API keys.

## gh-copilot

**gh-copilot (GitHub Copilot CLI)**


**Replaces:** — (official GitHub AI assistant) | **Language:** ⚠️ TypeScript | **Install:** via `spacecraft-missing-pkg` (gh extension: `github/gh-copilot`)

### Purpose
GitHub's official AI terminal assistant. Provides `gh copilot suggest` and `gh copilot explain`.

### Key commands
| Command | Meaning |
|---------|---------|
| `gh copilot suggest "QUERY"` | Suggest a command |
| `gh copilot explain "CMD"` | Explain a command |
| `gh copilot --help` | Help |

### Suggest target types
- `-t shell` — shell command (default)
- `-t gh` — gh CLI command
- `-t git` — git command

### Examples
1. Suggest a shell command: `gh copilot suggest "compress all .log files older than 7 days"`
2. Explain a command: `gh copilot explain "find . -name '*.rs' -newer file.txt"`
3. gh-specific: `gh copilot suggest -t gh "list my open PRs"`

### Gotchas
- Requires active GitHub Copilot subscription and `gh auth login`.
- Suggestions are not executed automatically — review first.

## grok-cli

**grok-cli (grok)**


**Replaces:** xAI web UI | **Language:** ⚠️ TypeScript/Bun | **Install:** via `spacecraft-missing-pkg` (npm package: `grok-cli` (Bun-published))

### Purpose
Open-source conversational AI agent for xAI's Grok models.

### Launch
```
grok                     # REPL
grok "<prompt>"          # one-shot
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-m MODEL` | Model override |
| `-p` | Non-interactive |

### Examples
1. Chat: `grok`
2. One-shot: `grok -p "summarise this" < article.txt`

### Gotchas
- Needs Bun runtime (or Node with polyfills).
- Requires xAI API key.

## gws-cli

**gws-cli (gws)**


**Replaces:** `gcloud`-based Google Workspace scripts | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `gws-cli`)

### Purpose
Unified Google Workspace CLI built to be equally usable by humans and AI agents. Drive, Docs, Sheets, Calendar, Gmail in one tool.

### Key commands
| Command | Meaning |
|---------|---------|
| `gws auth login` | OAuth authentication |
| `gws drive list` | List Drive files |
| `gws drive upload FILE` / `download ID` | Up/download |
| `gws docs read ID` / `append ID TEXT` | Docs manipulation |
| `gws sheets read ID RANGE` / `write ID RANGE VAL` | Sheets |
| `gws calendar list` / `create` | Calendar events |
| `gws mail send --to … --subject …` | Send email |
| `gws config` | View/set config |

### Examples
1. List Drive: `gws drive list --query "name contains 'Spacecraft Software'"`
2. Append to a Doc: `gws docs append DOC_ID "Session notes: …"`
3. Script-friendly output: `gws drive list -o json | jaq '.[] | .name'`

### Gotchas
- OAuth stores tokens under `$XDG_CONFIG_HOME/gws/` — treat as credentials.
- Designed for agent use — pairs well with `claude-code` MCP integration.

## kilo

**kilo**


**Replaces:** agentic engineering platforms | **Language:** ⚠️ TypeScript | **Install:** via `spacecraft-missing-pkg` (upstream)

### Purpose
Agentic engineering platform CLI. Orchestrates multi-step software tasks.

### Launch
```
kilo                     # start platform
kilo task "DESCRIPTION"  # submit a task
```

### Gotchas
- Project-specific configuration under `.kilo/` in the repo.
- Confirm model provider env vars are set before running (`OPENAI_API_KEY` / `ANTHROPIC_API_KEY`).

## kimi-cli

**kimi-cli (kimi)**


**Replaces:** general-purpose coding assistants | **Language:** ⚠️ | **Install:** via `spacecraft-missing-pkg` (upstream)

### Purpose
CLI for Moonshot AI. Long-context (≥200k token) specialisation — handy for large-codebase queries.

### Launch
```
kimi                     # REPL
kimi "<prompt>"          # one-shot
```

### Examples
1. Ingest a whole crate and ask a question: `cat src/**/*.rs | kimi "find every place we call .unwrap()"`
2. Summarise a long spec: `kimi -p "summarise key decisions" < design.md`

### Gotchas
- Requires Moonshot API credentials.
- Ingesting huge contexts can be slow/expensive — chunk when possible.

## kiro-cli

**kiro-cli (kiro)**


**Replaces:** general developer automation CLIs | **Language:** ⚠️ | **Install:** via `spacecraft-missing-pkg` (upstream)

### Purpose
AI-native CLI designed to supercharge developer workflows — scaffolding, command generation, repo navigation.

### Launch
```
kiro                     # interactive
kiro "<intent>"          # one-shot
```

### Gotchas
- Relatively new — feature set evolves; pin a known-good version in CI.
- Check `kiro --version` + upstream changelog before automation.

## minimax-cli

**minimax-cli (minimax)**


**Replaces:** vendor-specific coding agents | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream)

### Purpose
Terminal-native AI coding assistant powered by MiniMax models.

### Launch
```
minimax                  # REPL
minimax "<prompt>"       # one-shot
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-m MODEL` | Model override |
| `-p` | Non-interactive |
| `--config FILE` | Config |

### Examples
1. Interactive: `minimax`
2. One-shot review: `minimax -p "review for unsafe blocks" < src/lib.rs`

### Gotchas
- Requires MiniMax API credentials.
- Less mature than Claude Code / Codex — treat as secondary agent in pipelines.

## opencode

**opencode**


**Replaces:** closed-source AI coding agents | **Language:** 🐹 Go | **Install:** via `spacecraft-missing-pkg` (upstream installer)

### Purpose
Open-source AI coding assistant. Bring-your-own-model (OpenAI, Anthropic, local). Configurable agent loop.

### Launch
```
opencode                 # TUI
opencode "<prompt>"      # one-shot
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-m MODEL` / `--model` | Model override |
| `--provider NAME` | Provider override |
| `--config FILE` | Config |
| `-p` / `--print` | Non-interactive |
| `--mcp-config FILE` | MCP servers |

### Examples
1. Launch TUI: `opencode`
2. Non-interactive with Anthropic: `opencode -m claude-opus-4-7 "add logging to this module"`
3. Local model via Ollama: `opencode --provider ollama -m llama3.1 "…"`

### Gotchas
- Config lives in `~/.opencode/` — API keys stored here, treat like `~/.ssh/`.
- Mohamed's fork is `UnbreakableMJ/opencode` — check for pipeline-specific tweaks.
