# Text Editors

## amp

**amp**


**Replaces:** `vim` (minimal alternative) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `amp`)

### Purpose
Vi-inspired terminal editor. Smaller footprint than Helix, simpler than Vim, no plugin system.

### Launch
```
amp FILE
```

### Key bindings (modal, Vim-like)
| Key | Mode |
|-----|------|
| `Esc` | Normal |
| `i` | Insert |
| `s` | Select |
| `o` | Open (jump by pattern) |
| `g` | Go-to (workspace-aware) |
| `:` | Command |

### Examples
1. Edit: `amp README.md`
2. Jump to a symbol (workspace mode): `amp .` → `o` → type symbol

### Gotchas
- Minimal feature set by design — no LSP integration.
- Config: `$XDG_CONFIG_HOME/amp/`.

## helix

**helix (hx)**


**Replaces:** `vim`, `neovim` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `helix-term` (build locked); also distro-provided)

### Purpose
Post-modern modal editor with multiple cursors, tree-sitter syntax, and built-in LSP. No plugins needed for a full dev loop.

### Launch
```
hx FILE…
hx +N FILE           # open at line N
hx --health          # diagnose LSP/grammars
```

### Key bindings (sample)
| Key | Action |
|-----|--------|
| `Esc` | Normal mode |
| `i` / `a` / `o` | Insert before / after / open line |
| `w`/`b`/`e` | Word motions |
| `x` | Select line |
| `d` / `y` / `c` | Delete / yank / change |
| `u` / `U` | Undo / redo |
| `%s` | Select whole buffer |
| `g g` / `g e` | Top / bottom |
| `Space f` | File picker (fuzzy) |
| `Space b` | Buffer picker |
| `Space /` | Workspace grep |
| `Space k` | Hover docs (LSP) |
| `g d` | Go to definition |
| `g r` | References |
| `:` | Command mode (`:w`, `:q`, `:wq!`) |

### Examples
1. Edit: `hx src/main.rs`
2. Open multiple files: `hx Cargo.toml src/lib.rs`
3. Check LSP setup: `hx --health rust`
4. Edit config: `hx ~/.config/helix/config.toml`

### Gotchas
- Selection comes before action (`w d` = select-word-then-delete), unlike Vim's `dw`.
- LSP needs the language server installed separately (`rust-analyzer`, `gopls`, `clangd`, etc.).
- No plugin ecosystem yet — the tradeoff for a batteries-included core.

## msedit

**msedit**


**Replaces:** `nano`, minimal terminal editors | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `msedit`)

### Purpose
Minimalist terminal text editor. Launch, type, save, quit — no modes, no configuration.

### Launch
```
msedit FILE
```

### Key bindings (CUA-style)
| Key | Action |
|-----|--------|
| `Ctrl+S` | Save |
| `Ctrl+Q` | Quit |
| `Ctrl+X` | Cut line |
| `Ctrl+C` | Copy |
| `Ctrl+V` | Paste |
| `Ctrl+Z` / `Ctrl+Y` | Undo / redo |
| `Ctrl+F` | Find |

### Examples
1. Edit a file: `msedit notes.txt`
2. Create new: `msedit newfile.md`

### Gotchas
- Intentionally minimal — for any code work, use `helix` instead.
- No split windows, no LSP, no multi-file buffers.

## rsvim

**rsvim**


**Replaces:** `vim` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rsvim` (check upstream for status))

### Purpose
A Vim clone rebuilt from scratch in Rust. Aims at Vim-compatible keybindings and scripting while being memory-safe.

### Launch
```
rsvim FILE…
```

### Key bindings
Vim-standard modal editing: `i` insert, `Esc` normal, `hjkl` move, `:w`/`:q` commands, `dd` delete line, `yy` yank, `p` paste, `u` undo.

### Examples
1. Edit a file: `rsvim main.rs`
2. Open at line: `rsvim +42 main.rs`
3. Read stdin: `cmd | rsvim -`

### Gotchas
- Still early-stage — Vimscript/Lua plugin ecosystem is not supported.
- For production daily-driver editing, `helix` is more mature among the Rust options.
