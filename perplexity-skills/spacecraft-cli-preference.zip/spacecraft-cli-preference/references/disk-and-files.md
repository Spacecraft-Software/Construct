# Disk & Files

## broot

**broot (br)**


**Replaces:** `tree`, `ranger` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `broot`)

### Purpose
Tree-oriented file navigator with incremental filter-as-you-type and shell integration that updates your parent shell's `cwd`.

### Setup
```
broot --install     # sets up `br` shell function for cd-on-exit
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-h` | Show hidden |
| `-i` | Show gitignored |
| `-s` / `--sizes` | Show sizes |
| `-d` / `--dates` | Show mtimes |
| `-w` / `--whale-spotting` | Size-sorted descent (big-file hunt) |
| `-p` / `--permissions` | Show perms |
| `-g` / `--show-git-info` | Git statuses |
| `-c CMD` | Execute CMD on startup |

### Key bindings (in-app)
| Key | Action |
|-----|--------|
| Type | Filter |
| `↑`/`↓` | Navigate |
| `Enter` | Open / cd |
| `Alt+Enter` | cd + quit (via `br`) |
| `:` | Command input |
| `?` | Help |
| `Esc` | Clear |

### Examples
1. Navigate + cd: `br`
2. Hunt for big files: `br -w`
3. Filter Rust files by typing `/\.rs$`.

### Gotchas
- `br` (the shell wrapper) is what you should invoke — `broot` alone can't cd the parent shell.
- Config: `$XDG_CONFIG_HOME/broot/conf.hjson`.

## disktui

**disktui**


**Replaces:** `cfdisk`, `fdisk` (interactive) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `disktui`)

> **TTY-class and destructive — always a hand-off.** It needs a terminal the
> agent doesn't have, and it edits partition tables. Give the user the command
> and stop. See [local-execution.md](local-execution.md).

### Purpose
Interactive partition manager TUI with MBR/GPT support.

### Launch
```
sudo disktui [DEVICE]
```

### Key bindings
| Key | Action |
|-----|--------|
| `↑`/`↓` | Select partition |
| `n` | New |
| `d` | Delete |
| `t` | Change type |
| `w` | Write changes |
| `q` | Quit |

### Gotchas
- Writes are destructive — review with `lsblk` + `gptman` before `w`.
- Doesn't format filesystems — follow with `mkfs.*`.

## dua

**dua (dua-cli)**


**Replaces:** `du` / `ncdu` (interactive) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `dua-cli`)

### Purpose
Parallel disk-usage analyser with an interactive TUI mode for navigating and deleting large files.

### Key modes
| Command | Meaning |
|---------|---------|
| `dua PATHS…` | Summary of sizes (like `du -sh`, faster) |
| `dua i PATHS…` | **Interactive** TUI navigator |
| `dua a PATHS…` | Aggregate total across paths |

### Key flags
| Flag | Meaning |
|------|---------|
| `-t N` / `--threads N` | Parallelism |
| `-f FMT` / `--format FMT` | `metric`, `binary`, `bytes`, `GB`, `GiB`, `MB`, `MiB` |
| `-A` / `--apparent-size` | Apparent size |
| `-l` / `--count-hard-links` | Count hard-linked files each time |
| `-x` / `--stay-on-filesystem` | Don't cross mount points |

### Interactive keys
| Key | Action |
|-----|--------|
| `↑`/`↓`, `j`/`k` | Navigate |
| `Enter`, `l` | Descend |
| `u`, `h` | Up |
| `d` | Mark for deletion |
| `x` | Trash marked |
| `q` | Quit |

### Examples
1. Fast size of home: `dua ~`
2. Interactive cleanup: `dua i ~`
3. Multiple paths totalled: `dua a ~/Downloads ~/Documents`
4. Binary units: `dua -f binary /var`

### Gotchas
- Interactive `dua i` doesn't ask before deleting — confirm the marked list before hitting `x`.
- Doesn't traverse network mounts by default with `-x`.

## dust

**dust**


**Replaces:** `du` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `du-dust`)

### Purpose
Intuitive disk-usage visualiser. Shows a reverse bar-chart tree of what's eating your disk.

### Key flags
| Flag | Meaning |
|------|---------|
| `-d N` / `--depth N` | Max depth to display |
| `-n N` / `--number-of-lines N` | Show top N entries |
| `-r` / `--reverse` | Largest at bottom (classic order) |
| `-s` / `--apparent-size` | Apparent size, not on-disk |
| `-X PATH` / `--ignore-directory PATH` | Skip path |
| `-i` / `--ignore-hidden` | Skip hidden files |
| `-f` / `--filecount` | Count files instead of bytes |
| `-t N` / `--threads N` | Parallelism |
| `-b` / `--no-percent-bars` | No ASCII bars |

### Examples
1. Current directory overview: `dust`
2. Top 5 largest in home: `dust -n 5 ~`
3. Only two levels deep: `dust -d 2`
4. Count files, not bytes: `dust -f`
5. Exclude target/: `dust -X target -X node_modules`

### Gotchas
- By default shows the top 30-ish largest paths, not every child — combine with `-d` for a full picture.
- Symlinks aren't followed by default.
- Apparent size (`-s`) differs from on-disk allocation (holes, compression).

## fclones

**fclones**


**Replaces:** `fdupes`, `rmlint` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `fclones`)

> **`fclones group` is safe; `fclones remove` deletes files.** Stop at the
> group report, show it, and get consent before any `remove`/`link`/`dedupe`
> pass. See [local-execution.md](local-execution.md).

### Purpose
Parallel duplicate-file finder; can also deduplicate in place via hard/symlinks or reflinks.

### Key commands
| Command | Meaning |
|---------|---------|
| `fclones group PATHS…` | Find duplicates (default) |
| `fclones remove` | Delete files from a prior group output |
| `fclones link [--soft]` | Replace duplicates with hardlinks (or symlinks) |
| `fclones dedupe` | Btrfs/XFS reflink-based dedup |

### Key flags
| Flag | Meaning |
|------|---------|
| `-R` / `--recursive` | Recurse into directories (on by default for positional dirs) |
| `-s SIZE` / `--min-size SIZE` | Skip files below this size (e.g. `1M`) |
| `-H` / `--match-links` | Treat hardlinks as duplicates |
| `--hash-fn ALGO` | `metro`, `xxhash3`, `blake3`, `sha256` |
| `-o FILE` / `--output FILE` | Write group list |
| `-f FMT` / `--format FMT` | `default`, `csv`, `json`, `fdupes` |

### Examples
1. Find duplicates under home: `fclones group ~`
2. Save groups, then review and delete: `fclones group ~/Pictures -o dupes.txt && fclones remove < dupes.txt`
3. Hardlink duplicates in a dataset: `fclones group data/ | fclones link`
4. Only files ≥1 MB: `fclones group -s 1M ~/Downloads`
5. JSON output: `fclones group -f json /srv > dupes.json`

### Gotchas
- `remove`/`link`/`dedupe` read previous `group` output from stdin — always review first.
- Reflink dedup (`dedupe`) requires btrfs/xfs with reflink support.
- Hash choice affects speed vs. collision safety; `blake3` is a good balance.

## gptman

**gptman**


**Replaces:** `gdisk`, `sgdisk` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `gptman`)

> **Never run unprompted.** Writing a partition table on the wrong device
> destroys everything on it. The agent may run read-only inspection; every
> write is a hand-off to the user. See [local-execution.md](local-execution.md).

### Purpose
Scriptable GPT partition table manipulation. Create, modify, clone partitions non-interactively.

### Key commands
| Command | Meaning |
|---------|---------|
| `gptman -l DEVICE` | List GPT partitions |
| `gptman DEVICE` | Interactive edit mode |
| `gptman -i DEVICE` | Print GPT info |
| `gptman -d DEVICE` | Write defaults (blank GPT) |

### Interactive commands
| Key | Action |
|-----|--------|
| `p` | Print table |
| `n` | New partition |
| `d` | Delete |
| `t` | Type GUID |
| `w` | Write |
| `q` | Quit without saving |

### Examples
1. List partitions: `gptman -l /dev/nvme0n1`
2. Edit: `sudo gptman /dev/nvme0n1`
3. JSON scripting target: pair with a shell wrapper for CI disk provisioning

### Gotchas
- Always unmount before editing.
- Partition numbers are 1-indexed.

## kondo

**kondo**


**Replaces:** ad-hoc `rm -rf target/ node_modules/` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `kondo`)

> **Destructive — consent required.** This deletes real directories on the
> user's machine, and `-a`/`--all` does it with **no confirmation**. Run it
> with no flags first to produce the list, show what would be removed, and
> wait for the go-ahead. Never pass `-a` unprompted.
> See [local-execution.md](local-execution.md).

### Purpose
Finds and deletes build/dependency artifacts from software projects (`target/`, `node_modules/`, `build/`, `dist/`, `.gradle/`, etc.) across many languages.

### Key flags
| Flag | Meaning |
|------|---------|
| `-a` / `--all` | Delete all without confirmation |
| `-d DAYS` / `--older DAYS` | Only include projects untouched for N days |
| `-o FMT` / `--output FMT` | `default`, `json` |
| `-f` / `--follow-symlinks` | Follow symlinks |
| `-q` / `--quiet` | Suppress output |
| `-i PATTERN` / `--ignored PATTERN` | Ignore paths by pattern |

### Examples
1. Interactive cleanup of home: `kondo ~`
2. Auto-clean everything older than 30 days: `kondo -a -d 30 ~/code`
3. Dry-run inventory as JSON: `kondo -o json ~`
4. Clean current directory only: `kondo .`

### Gotchas
- Deletion is **irrecoverable** — commit or push before running `-a`.
- Detects projects by marker files (`Cargo.toml`, `package.json`, etc.); mixed-layout repos may double-count.

## superfile

**superfile (spf)**


**Replaces:** TUI file managers | **Language:** 🐹 Go | **Install:** via `spacecraft-missing-pkg` (upstream installer; also distro-provided)

### Purpose
Visually rich TUI file manager with tabs, split panes, built-in image previews, and a modern look.

### Launch
```
spf           # current dir
spf PATH      # specific dir
```

### Key bindings
| Key | Action |
|-----|--------|
| `h`/`j`/`k`/`l` | Navigate |
| `Enter` | Open |
| `a` | New file/dir |
| `r` | Rename |
| `c` / `x` / `v` | Copy / cut / paste |
| `d` | Delete |
| `/` | Search |
| `Tab` / `Shift+Tab` | Next/prev pane |
| `L` | New pane |
| `H` | Close pane |
| `q` | Quit |

### Gotchas
- Config: `$XDG_CONFIG_HOME/superfile/`.
- Not as scriptable as `yazi`; prefer yazi for automation contexts.

## yazi

**yazi**


**Replaces:** `ranger`, `nnn`, `mc` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crates: `yazi-fm` + `yazi-cli`)

### Purpose
Blazing-fast async terminal file manager with image previews, plugin system, and vim-like keybindings. Spacecraft Software's preferred TUI file manager.

### Launch
```
yazi [PATH]
```

### Key bindings
| Key | Action |
|-----|--------|
| `h`/`j`/`k`/`l` | Navigate |
| `g`/`G` | Top / bottom |
| `Space` | Select |
| `v` | Visual mode |
| `y` / `d` / `p` | Yank / cut / paste |
| `a` | Create file/dir (trailing `/` = dir) |
| `r` | Rename |
| `o` / `O` | Open / open with picker |
| `f` | Filter |
| `/` | Find (forward) |
| `s` | Sort menu |
| `.` | Toggle hidden |
| `t` | New tab |
| `[` / `]` | Prev/next tab |
| `;` | Command input |
| `q` | Quit |

### Examples
1. Launch at $HOME: `yazi ~`
2. Change directory on exit: `function y { yazi --cwd-file=/tmp/yazicwd "$@" && cd "$(< /tmp/yazicwd)"; }`
3. Set default editor: export `EDITOR=hx` before launch

### Gotchas
- Image previews need a graphics-capable terminal (kitty, WezTerm, Ghostty) or `ueberzugpp`.
- Config: `$XDG_CONFIG_HOME/yazi/{yazi,keymap,theme}.toml`.
- `cd-on-exit` requires the shell wrapper shown above; the binary itself cannot `cd` in the parent shell.
