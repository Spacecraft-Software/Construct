# Process & Monitoring

## bandwhich

**bandwhich**


**Replaces:** `iftop`, `nethogs` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `bandwhich`)

### Purpose
Per-process/per-connection bandwidth monitor. Shows which process is using how much in real time.

### Key flags
| Flag | Meaning |
|------|---------|
| `-i IFACE` / `--interface IFACE` | Specific interface |
| `-r` / `--raw` | Machine-readable output, no TUI |
| `-n` / `--no-resolve` | Don't resolve IPs to hostnames |
| `-s` / `--show-dns` | Show DNS queries |
| `-d SEC` / `--dns-server` | Use specific DNS server |
| `-p` / `--processes` | Processes view only |
| `--total-utilization` | Include total line |

### Examples
1. Live TUI: `sudo bandwhich`
2. Single NIC: `sudo bandwhich -i eth0`
3. Scripting (one sample): `sudo bandwhich --raw -n | head`
4. No DNS lookups (lower latency): `sudo bandwhich -n`

### Gotchas
- Requires raw socket access — root or `CAP_NET_RAW,CAP_NET_ADMIN`.
- Running in a Docker container needs `--cap-add` + `--network=host`.

## bottom

**bottom (btm)**


**Replaces:** `top`, `htop` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `bottom`)

### Purpose
Cross-platform TUI system monitor with CPU, memory, network, disk, process, and temperature graphs.

### Key flags (CLI)
| Flag | Meaning |
|------|---------|
| `-b` / `--basic` | Basic layout (no graphs) |
| `-t N` / `--rate N` | Refresh rate (ms) |
| `-S` / `--case_sensitive` | Case-sensitive process search |
| `--tree` | Process tree layout |
| `--battery` | Show battery widget |
| `--celsius` / `--fahrenheit` / `--kelvin` | Temperature units |
| `-g` / `--group_processes` | Group same-name processes |
| `-m` / `--mem_as_value` | Show mem as value, not % |
| `-C FILE` / `--config_location FILE` | Config |

### Key bindings (in TUI)
| Key | Action |
|-----|--------|
| `q` | Quit |
| `?` | Help |
| `/` | Search processes |
| `t` | Toggle tree |
| `dd` | Kill process |
| `e` | Expand widget |
| `Esc` | Close dialog/search |

### Examples
1. Launch: `btm`
2. Process tree, Celsius: `btm --tree --celsius`
3. Minimal layout on a low-res terminal: `btm -b`

### Gotchas
- Heavy graph rendering in Tmux can cause flicker — try `-b` or a lower refresh.
- Custom layouts via `bottom.toml` in `$XDG_CONFIG_HOME/bottom/`.

## kmon

**kmon**


**Replaces:** `lsmod`, `modinfo`, `modprobe` (browsing) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `kmon`)

### Purpose
TUI for Linux kernel module inspection and management. Load, unload, inspect parameters, browse kernel logs.

### Launch
```
sudo kmon
```

### Key bindings
| Key | Action |
|-----|--------|
| `↑`/`↓` | Navigate modules |
| `Enter` | Show info |
| `l` | Load module |
| `u` | Unload |
| `d` | Dependencies |
| `/` | Search |
| `k` | Kernel activity log |
| `?` | Help |
| `q` | Quit |

### Gotchas
- Unloading critical modules (e.g. current filesystem driver) can crash the session.
- Needs root for load/unload operations.

## macchina

**macchina**


**Replaces:** `neofetch`, `fastfetch` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `macchina`)

### Purpose
Fast system-info fetcher. Customisable readouts, themes, ASCII art.

### Key flags
| Flag | Meaning |
|------|---------|
| `-t THEME` / `--theme THEME` | Named theme |
| `-o ITEM` / `--show ITEM` | Only show this item (repeatable) |
| `-H ITEM` / `--hide ITEM` | Hide item |
| `--list-themes` | Available themes |
| `-c FILE` / `--config FILE` | Config file |
| `-p` / `--predefined` | Use predefined logo |
| `-v` | Verbose |

### Examples
1. Default: `macchina`
2. Minimal (OS + kernel only): `macchina -o os -o kernel`
3. Custom theme: `macchina -t Helium`
4. Scriptable (no ASCII): `macchina -H logo`

### Gotchas
- Themes live in `$XDG_CONFIG_HOME/macchina/themes/`.
- Some readouts need permissions (e.g. battery on locked-down containers).

## procs

**procs**


**Replaces:** `ps` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `procs`)

### Purpose
Modern `ps` with colour, tree view, additional columns (TCP/UDP ports, Docker, read/write throughput), and keyword filtering.

### Key flags
| Flag | Meaning |
|------|---------|
| `<KEYWORD>` | Positional: filter by name/user/PID substring |
| `--tree` / `-t` | Tree layout |
| `--sortd KEY` / `--sorta KEY` | Sort descending / ascending by column |
| `--watch N` / `-W N` | Refresh every N seconds (like `top`) |
| `--watch-interval N` | Seconds between refreshes |
| `--insert COL` | Add column (e.g. `tcp`, `udp`, `docker`) |
| `--color always` | Force colour when piping |
| `--thread` / `-T` | Show threads |
| `--pager disable` | Don't paginate |

### Examples
1. Find Rust compiler processes: `procs rustc`
2. Process tree: `procs --tree`
3. Refreshing top-like view sorted by CPU: `procs --watch 1 --sortd cpu`
4. Show processes of a user: `procs $USER`
5. Find a PID holding a port: `procs --insert tcp | rg :8080`
6. Threads as well: `procs --thread firefox`

### Gotchas
- Unlike `ps`, `procs` has no direct equivalent of `-eLf` — use `--thread`.
- On some distros port columns require `CAP_NET_RAW` or root.
- Default output wraps to terminal width; use `--pager disable` + explicit columns in scripts.
