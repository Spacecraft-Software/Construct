# File & Text

## bat

**bat**


**Replaces:** `cat` (for viewing) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `bat`; also distro-provided)

### Purpose
`cat` with syntax highlighting, line numbers, git diff gutter, and paging. For interactive viewing — **do not** pipe `bat` into other tools unless you pass `--plain`.

### Key flags
| Flag | Meaning |
|------|---------|
| `-p` / `--plain` | No decorations; pipe-safe |
| `-n` / `--number` | Only line numbers (no other decorations) |
| `-A` / `--show-all` | Show non-printable characters |
| `--paging=never` | Disable pager |
| `-l LANG` / `--language LANG` | Force syntax (e.g. `yaml`, `rust`) |
| `--theme THEME` | Pick colour theme (`bat --list-themes`) |
| `--diff` | Highlight only modified lines |
| `-r N:M` / `--line-range N:M` | Print only lines N to M |
| `--style STYLES` | Comma list: `numbers,changes,header,grid,snip,rule` or `plain`/`full` |

### Examples
1. View with line numbers: `bat src/main.rs`
2. Multiple files concatenated for display: `bat Cargo.toml src/lib.rs`
3. Pipe-safe (for scripts): `bat --plain file.txt | head`
4. Highlight a JSON blob from stdin: `curl -s api | bat -l json`
5. Show only lines 10–40: `bat -r 10:40 logfile`
6. Diff-style: `git diff | bat --language diff`

### Gotchas
- Default output includes escape codes — if the consumer isn't a terminal, always `--plain`.
- `bat` is sometimes installed as `batcat` on Debian/Ubuntu; alias or symlink: `ln -s "$(which batcat)" ~/.local/bin/bat`.
- Replace the pager with `less -R` to keep colours: `export BAT_PAGER='less -R'`.

## delta

**delta**


**Replaces:** `diff` pager for git | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `git-delta`)

### Purpose
Syntax-highlighted diffs for `git`, `diff`, `grep`. Side-by-side or unified view. Integrates via `.gitconfig`.

### Setup (once per user)
```ini
# ~/.gitconfig
[core]
    pager = delta
[interactive]
    diffFilter = delta --color-only
[delta]
    navigate = true
    side-by-side = true
    line-numbers = true
    syntax-theme = Dracula
[merge]
    conflictStyle = diff3
```

### Key flags
| Flag | Meaning |
|------|---------|
| `--side-by-side` | Two-column view |
| `--line-numbers` | Gutter line numbers |
| `--navigate` | `n`/`N` between files in pager |
| `--syntax-theme THEME` | e.g. `Dracula`, `GitHub`, `OneHalfDark` |
| `--plus-style`, `--minus-style` | Colour overrides |
| `--features PROFILE` | Named config profile from `.gitconfig` |
| `--light` / `--dark` | Light/dark background hints |

### Examples
1. Pipe a diff: `git diff | delta`
2. Pretty grep (rg): `rg -p "unwrap" | delta`
3. Show a commit: `git show HEAD` (uses delta as pager once configured)
4. Compare two files: `delta a.txt b.txt`

### Gotchas
- Must be set as the git pager to show in `git log -p`, `git show`, etc.
- `merge.conflictStyle = diff3` (or `zdiff3`) makes conflict markers far clearer.
- `BAT_THEME`/`DELTA_FEATURES` env vars can override config.

## eza

**eza**


**Replaces:** `ls` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `eza`; also distro-provided)

### Purpose
Modern `ls` replacement with git status, tree view, icons, and hyperlinks. Maintained fork of the unmaintained `exa`.

### Key flags
| Flag | Meaning |
|------|---------|
| `-1` / `--oneline` | One entry per line |
| `-a` / `--all` | Include dotfiles (use `-aa` to include `.` and `..`) |
| `-l` / `--long` | Long listing (perms, owner, size, mtime) |
| `-h` / `--header` | Add column headers in long mode |
| `-T` / `--tree` | Recursive tree view |
| `-L N` / `--level N` | Limit tree depth to N |
| `-s KEY` / `--sort KEY` | Sort by `name`, `size`, `modified`, `extension`, `type` |
| `-r` / `--reverse` | Reverse sort order |
| `--git` | Show per-file git status in long mode |
| `--git-ignore` | Hide files matched by `.gitignore` |
| `--icons=auto` | Show Nerd Font icons |
| `--group-directories-first` | Directories before files |

### Examples
1. Long listing with git, headers, and icons: `eza -lah --header --git --icons=auto`
2. Three-level tree: `eza -T -L 3`
3. Largest files first: `eza -l -s size -r`
4. Only Rust files, sorted by mtime: `eza -l -s modified *.rs`
5. Respect `.gitignore`: `eza --git-ignore`

### Gotchas
- Colour output is disabled when piped; force with `--color=always`.
- `--icons` requires a Nerd Font terminal.
- Not 100% flag-compatible with GNU `ls`; script authors depending on exact `ls -l` columns should use `ls` directly.

## fd

**fd**


**Replaces:** `find` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `fd-find`; also distro-provided)

### Purpose
User-friendly `find` replacement. Smart-case, regex, respects `.gitignore` and hidden-file rules by default, parallel execution.

### Key flags
| Flag | Meaning |
|------|---------|
| `-H` / `--hidden` | Include hidden files |
| `-I` / `--no-ignore` | Ignore `.gitignore`/`.ignore` |
| `-u` | Shortcut for `--hidden --no-ignore` |
| `-t TYPE` / `--type TYPE` | `f` file, `d` directory, `l` symlink, `x` executable, `e` empty |
| `-e EXT` / `--extension EXT` | Filter by extension (no leading dot) |
| `-s` / `--case-sensitive` | Force case-sensitive |
| `-g GLOB` / `--glob GLOB` | Glob instead of regex |
| `-S SIZE` / `--size SIZE` | e.g. `+10M`, `-1k` |
| `--changed-within DUR` | e.g. `1h`, `2d`, `2weeks` |
| `-x CMD` / `--exec CMD` | Run `CMD` per match (parallel) |
| `-X CMD` / `--exec-batch CMD` | Run `CMD` with all matches appended |
| `-0` | NUL-separated output for piping to `xargs -0` |

### Examples
1. Find all Rust files: `fd -e rs`
2. Case-sensitive search for `Main.rs`: `fd -s Main.rs`
3. Files larger than 10 MiB: `fd -S +10M`
4. Modified in the last day, executable: `fd -t x --changed-within 1d`
5. Batch-delete `.bak` files: `fd -e bak -X rm`
6. Find and format all Rust sources: `fd -e rs -x rustfmt`

### Gotchas
- Pattern is a **regex** by default; use `-g` for globs.
- `.gitignore`/hidden files excluded unless `-H -I` or `-u`.
- On Debian/Ubuntu the binary is `fdfind`; symlink to `fd` if you prefer.

## jaq

**jaq**


**Replaces:** `jq` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `jaq`)

### Purpose
Faster, near drop-in `jq` clone. Compatible with most `jq` filters, written in safe Rust.

### Key flags
| Flag | Meaning |
|------|---------|
| `-r` / `--raw-output` | Strings without JSON quoting |
| `-R` / `--raw-input` | Input is raw strings, one per line |
| `-s` / `--slurp` | Read whole input as single array |
| `-c` / `--compact-output` | One JSON doc per line |
| `--tab` | Indent with tabs |
| `--indent N` | Indent with N spaces |
| `-e` / `--exit-status` | Exit non-zero on null/false |
| `--arg NAME VALUE` | Bind string variable |
| `--argjson NAME VALUE` | Bind JSON variable |

### Examples
1. Pretty-print: `curl -s api | jaq .`
2. Extract field: `jaq -r '.name' package.json`
3. Filter array: `jaq '.[] | select(.active)' users.json`
4. Group and count: `jaq 'group_by(.kind) | map({kind: .[0].kind, n: length})'`
5. Build object: `jaq -n --arg v 1.0 '{version: $v, generated: now}'`
6. Slurp one file: `jaq -s 'add' a.json`
   (`jaq -s … a.json b.json` slurps **per file** and runs the filter twice —
   see Gotchas.)

### Gotchas
**`jaq` is not a drop-in for `jq`, and `alias jq = jaq` will break scripts.**
Use **Pathfinder** (`https://Pathfinder.SpacecraftSoftware.org/`) when existing
jq scripts have to keep working; it translates the command line, supplies the
missing builtins, and reports what it cannot repair. Measured against jq 1.8.1:

- **No auto-vivification** — the one that actually bites. `jq` creates missing
  containers along an assignment path; `jaq` errors.
  `echo null | jaq '.a.b = 1'` → `cannot use null as iterable`, where `jq`
  gives `{"a":{"b":1}}`. Every "build the object as you go" idiom breaks,
  including `reduce … (null; .[$k] = …)`.
- **Several input files are not one stream.** `jq` concatenates them; `jaq`
  runs the whole filter once per file, so `jaq -s 'add' a.json b.json` prints
  two results rather than one. Affects `-s`, `input` and `inputs`.
- **Output-format flags are not last-wins.** `jq -c --tab` pretty-prints with
  tabs; `jaq -c --tab` is compact.
- **22 jq builtins are missing**, including `tostream`, `fromstream`, `IN`,
  `INDEX`, `JOIN`, `builtins`, `input_filename` and `$__loc__`.
- **9 jq flags are rejected** with `unknown flag`: `-a`, `--seq`, `--stream`,
  `--stream-errors`, `--jsonargs`, `--unbuffered`, `-b`, `--argfile`, and the
  attached `-Ldir` spelling.
- `"a" * 0` is `null` (jq: `""`); `1 / 0` is `Infinity`, which is invalid JSON
  on stdout (jq errors).
- Error messages differ from `jq`; adapt CI assertions accordingly. The exit
  **codes** do match jq in every case tested.

`jaq` has one flag `jq` lacks: **`-i`/`--in-place` rewrites the input file**.
Never pass an unrecognised flag through to it blindly.

## ouch

**ouch**


**Replaces:** `tar`, `gzip`, `zip`/`unzip`, `7z`, `xz` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `ouch`)

### Purpose
One command for all archive formats. Format inferred from extension. Supports tar, zip, 7z, gz, bz2, xz, zstd, lz4, sz.

### Key flags
| Flag | Meaning |
|------|---------|
| `compress` (or `c`) | Create archive |
| `decompress` (or `d`) | Extract archive |
| `list` (or `l`) | List contents |
| `-y` / `--yes` | Answer yes to all prompts |
| `-n` / `--no` | Answer no to all prompts |
| `-d DIR` / `--dir DIR` | Extract to directory |
| `--format FMT` | Override format detection |

### Examples
1. Compress: `ouch compress src/ src.tar.gz`
2. Multiple inputs into zip: `ouch compress a b c bundle.zip`
3. Nested formats: `ouch compress dir/ out.tar.zst`
4. Decompress into a specific directory: `ouch decompress archive.tar.xz -d extracted/`
5. List archive contents: `ouch list archive.7z`
6. Auto-yes overwrite: `ouch -y d backup.zip`

### Gotchas
- Format is inferred from the output filename's extensions — `.tar.gz` works, `.tgz` too.
- For huge archives, `tar` with pipeline tools is still more memory-efficient.
- No streaming mode; reads the whole archive metadata up front.

## ripgrep

**ripgrep (rg)**


**Replaces:** `grep -r` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `ripgrep`; also distro-provided)

### Purpose
Fastest recursive search tool. Respects `.gitignore`, understands Unicode, parallel by default.

### Key flags
| Flag | Meaning |
|------|---------|
| `-i` / `--ignore-case` | Case-insensitive |
| `-S` / `--smart-case` | Case-insensitive unless pattern has uppercase |
| `-F` / `--fixed-strings` | Literal (non-regex) match |
| `-w` / `--word-regexp` | Match whole words |
| `-l` / `--files-with-matches` | Only list filenames |
| `-c` / `--count` | Count matches per file |
| `-n` / `--line-number` | Show line numbers (default on TTY) |
| `-A N`, `-B N`, `-C N` | Context lines after / before / both |
| `-t TYPE` / `--type TYPE` | Filter by type (e.g. `rust`, `py`, `md`); see `rg --type-list` |
| `-T TYPE` / `--type-not TYPE` | Exclude type |
| `-g GLOB` / `--glob GLOB` | Include/exclude glob (prefix with `!` to negate) |
| `--hidden` | Include hidden files |
| `-u` | Loosen filtering (`-u` gitignore, `-uu` hidden, `-uuu` binary) |
| `-z` / `--search-zip` | Search inside compressed files |
| `-r REPL` / `--replace REPL` | Display with replacement (non-destructive) |
| `--json` | Machine-readable output |

### Examples
1. Recursive search in the tree: `rg "TODO"`
2. Case-insensitive, whole word: `rg -iw "fixme"`
3. Only Rust files, with 2 lines of context: `rg -t rust -C 2 "unsafe"`
4. List files mentioning a symbol: `rg -l "tokio::spawn"`
5. Exclude tests: `rg "unwrap" -g '!tests/*'`
6. Search compressed logs: `rg -z "panic" /var/log/*.gz`
7. JSON output (for scripting): `rg --json "error" | jaq '. | select(.type=="match")'`

### Gotchas
- `.gitignore` + hidden-file filtering is on by default — use `-uu` to match everything.
- Patterns are Rust regex (similar to PCRE, but no backreferences). Use `-F` if your pattern has regex metacharacters.
- Binary files skipped by default; `-a` to force text treatment.

## rustybox

**rustybox**


**Replaces:** `busybox` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rustybox`)

### Purpose
100% Rust reimplementation of BusyBox — a single multicall binary providing tiny versions of common Unix tools. Suited for embedded / minimal container images where you want memory-safe primitives.

### Usage
Symlink `rustybox` under each applet name, or invoke via the multicall binary:
```
rustybox ls -la
rustybox cat /etc/os-release
```

### Examples
1. List applets: `rustybox --list`
2. Busybox-style applet call: `rustybox sh -c 'echo hi'`
3. Static Linux container with rustybox + distroless: ship a single `/bin/rustybox` binary with symlinks.

### Gotchas
- Not all BusyBox applets exist yet; coverage is growing but incomplete.
- Applet behaviour may differ slightly from BusyBox for edge cases; test CI.

## sd

**sd**


**Replaces:** `sed` (for simple find/replace) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `sd`)

### Purpose
Intuitive find-and-replace. Regex by default, no `s/…/…/g` ceremony, in-place or streaming.

### Key flags
| Flag | Meaning |
|------|---------|
| `-p` / `--preview` | Dry-run: show what would change |
| `-s` / `--string-mode` | Literal match (no regex) |
| `-f FLAGS` / `--flags FLAGS` | Regex flags: `i` case-insensitive, `m` multiline, `s` dotall, `w` whole word |

### Examples
1. Replace in a file in place: `sd "foo" "bar" file.txt`
2. Across many files: `fd -e rs -x sd "old_name" "new_name"`
3. Stream from pipe: `echo "hello world" | sd "world" "rust"`
4. Preview before applying: `sd -p "unwrap" "expect" src/main.rs`
5. Case-insensitive: `sd -f i "error" "ERROR" log.txt`
6. Literal string (no regex escaping): `sd -s "a.b.c" "x.y.z" file.txt`

### Gotchas
- Writes in place by default — always preview first on untracked files.
- No address ranges or commands like `sed` — it's substitution-only. Complex scripts still need `sed` or `awk`.
- Backslash references use `$1`, `$2` (not `\1`).

## tokei

**tokei**


**Replaces:** `cloc`, `wc -l` (for code) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `tokei`)

### Purpose
Fast code statistics: lines of code, comments, blanks, grouped by language. Respects `.gitignore`.

### Key flags
| Flag | Meaning |
|------|---------|
| `-t LANG[,LANG]` / `--type` | Only count these languages |
| `-e PATH` / `--exclude PATH` | Exclude path (gitignore-style) |
| `-s KEY` / `--sort KEY` | Sort by `lines`, `blanks`, `code`, `comments`, `files` |
| `-o FMT` / `--output FMT` | `json`, `yaml`, `toml`, `cbor` |
| `-f` / `--files` | Per-file breakdown |
| `--hidden` | Include hidden files |
| `-C` / `--compact` | Condensed output |

### Examples
1. Count this project: `tokei`
2. Only Rust and TOML: `tokei -t Rust,TOML`
3. Per-file breakdown sorted by code: `tokei -f -s code`
4. JSON for scripting: `tokei -o json | jaq '.Rust.code'`
5. Exclude vendor: `tokei -e vendor/ -e third_party/`

### Gotchas
- Counts by extension + heuristics; generated files inflate numbers — exclude them.
- Comment detection isn't perfect for obscure languages; spot-check with `-f`.

## uutils

**uutils (coreutils)**


**Replaces:** GNU coreutils | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `coreutils`; distro package: `rust-coreutils`)

### Purpose
Cross-platform, memory-safe rewrite of GNU coreutils (`ls`, `cp`, `mv`, `rm`, `mkdir`, `cat`, `sort`, `uniq`, …). Aims for GNU compatibility; used as default coreutils in Ubuntu 25.10 and beyond.

### Usage
Invoke individual utilities either by symlink name (`ls`, `cp`, …) or via the multicall binary:
```
coreutils ls -la
coreutils sort file
```

### Install as system coreutils
Route provisioning through `spacecraft-missing-pkg`. Making uutils *the*
system coreutils is a durable, system-wide change — propose it, don't perform
it:
- NixOS: `environment.systemPackages = [ pkgs.uutils-coreutils ];` and prefer via PATH order.
- Home Manager: `home.packages = [ pkgs.uutils-coreutils ];`
- Arch: distro package `uutils-coreutils` (community).
- Elsewhere: the `coreutils` crate, symlinked per tool.

### Examples
1. Drop-in GNU replacement on a test shell: `PATH="$HOME/.cargo/bin:$PATH" ls -la`
2. List available tools: `coreutils --list`
3. Multicall invocation: `coreutils cp src dst`

### Gotchas
- A few flags from GNU coreutils are not yet implemented — check `<tool> --help`.
- Switching system coreutils wholesale can break scripts that depend on GNU-specific edge cases; migrate gradually.
