# Communication

## disrust

**disrust**


**Replaces:** Discord desktop client (TUI alternative) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `disrust`)

### Purpose
Terminal-based Discord client.

### Launch
```
disrust
```

### Key bindings
| Key | Action |
|-----|--------|
| `↑`/`↓` | Navigate |
| `Tab` | Switch panes |
| `Enter` | Select / send |
| `Ctrl+Q` | Quit |

### Gotchas
- Unofficial — using third-party Discord clients can violate Discord's ToS; use at your own risk.
- Token-based login requires manually extracting your Discord token.

## iamb

**iamb**


**Replaces:** Matrix clients (TUI, Vim-like) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `iamb`)

### Purpose
Vim-like terminal Matrix client with multi-room support, modal editing, E2EE.

### Launch
```
iamb
```

### Key bindings (modal, Vim-style)
| Key | Action |
|-----|--------|
| `i` / `Esc` | Insert / normal mode |
| `:` | Command mode |
| `:join ROOM` | Join |
| `:verify` | Device verification |
| `:leave` | Leave room |
| `Ctrl+W h/j/k/l` | Navigate splits |
| `Ctrl+O` / `Ctrl+I` | History back / forward |
| `/` | Search |

### Examples
1. First-time config: edit `$XDG_CONFIG_HOME/iamb/config.toml` with your server/user
2. Join a room: `:join #rust:matrix.org`
3. Direct message: `:dms` to open DM list

### Gotchas
- First sync on a busy account takes a while.
- E2EE device verification required for encrypted rooms.

## matrix-commander

**matrix-commander-rs**


**Replaces:** scripted Matrix interactions | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `matrix-commander-rs`)

### Purpose
Scripting-oriented Matrix CLI. Send/receive messages, manage rooms, verify devices — pipe-friendly.

### Key flags
| Flag | Meaning |
|------|---------|
| `--login` | Initial login (interactive) |
| `-m MSG` / `--message MSG` | Send text |
| `-i FILE` / `--image FILE` | Send image |
| `-f FILE` / `--file FILE` | Send file |
| `-r ROOM` / `--room ROOM` | Room alias/ID |
| `-l` / `--listen` | Listen for messages (once/tail/forever) |
| `--sync` | Sync server state |
| `--store DIR` | Credential store path |
| `--verify emoji` | SAS-emoji device verification |
| `--room-create` / `--room-invite` | Room ops |

### Examples
1. Login: `matrix-commander-rs --login`
2. Send a message: `matrix-commander-rs -r '!roomid:server' -m "deploy starting"`
3. Pipe a build log: `cargo test 2>&1 | matrix-commander-rs -r '#ci:server' -m -`
4. Listen for new messages: `matrix-commander-rs -l tail`

### Gotchas
- Device verification (`--verify emoji`) required for E2EE rooms before encrypted messages work.
- Store directory holds session keys — back up securely.

## rivetui

**RivetUI**


**Replaces:** Discord TUI alternative | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rivetui`)

### Purpose
Alternative terminal Discord client with a richer UI than `disrust`.

### Launch
```
rivetui
```

### Gotchas
- Same ToS caveat as `disrust` — Discord prohibits third-party clients.
- Check upstream for active maintenance status before adopting.

## rumatui

**rumatui**


**Replaces:** Matrix TUI alternative | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rumatui`)

### Purpose
Alternative terminal Matrix client with a simpler, non-modal UI.

### Launch
```
rumatui
```

### Key bindings
| Key | Action |
|-----|--------|
| `↑`/`↓` | Navigate rooms / messages |
| `Enter` | Select room / send |
| `Tab` | Switch panes |
| `Ctrl+Q` | Quit |

### Gotchas
- Development pace is slower than `iamb`; prefer iamb for feature-completeness.
- E2EE support varies by version — check README for current status.
