# Networking

## curl

**curl**


**Replaces:** — (the standard itself) | **Language:** ⚠️ C | **Install:** via `spacecraft-missing-pkg` (distro-provided (universally available))

### Purpose
The gold standard for HTTP/FTP/SMTP/etc. data transfer. Keep `curl` whenever a command must run portably across systems without Rust toolchain installed. Prefer `xh` for interactive/one-off API calls.

### Key flags
| Flag | Meaning |
|------|---------|
| `-s` / `--silent` | Suppress progress |
| `-S` / `--show-error` | With `-s`, still show errors |
| `-f` / `--fail` | Non-zero exit on HTTP ≥400 |
| `-L` / `--location` | Follow redirects |
| `-o FILE` / `-O` | Save to FILE / original name |
| `-X METHOD` | HTTP method |
| `-d DATA` / `--data` | POST body (URL-encoded) |
| `--data-raw`, `--data-binary` | No special interpretation |
| `-H HEADER` | Custom header |
| `-u USER:PASS` | Basic auth |
| `-b FILE` / `-c FILE` | Read / write cookie jar |
| `-k` / `--insecure` | Skip TLS verify |
| `-I` / `--head` | HEAD request |
| `-w FORMAT` | Write-out format (e.g. `%{http_code}`) |
| `--resolve HOST:PORT:IP` | Force DNS |
| `--retry N` / `--retry-delay N` | Retry on transient failures |
| `-C -` | Resume a partial download |

### Examples
1. Silent + fail-on-error download: `curl -sSfLO https://example.com/file.tar.gz`
2. POST JSON: `curl -fsS -X POST -H 'Content-Type: application/json' -d '{"a":1}' URL`
3. Download with retry: `curl --retry 5 --retry-delay 2 -LO URL`
4. Only HTTP code: `curl -s -o /dev/null -w '%{http_code}\n' URL`
5. Auth probe: `curl -fsS -u "$USER:$TOKEN" https://api.example.com/me`
6. Resume: `curl -C - -LO URL`

### Gotchas
- Always combine `-sS` when scripting so silent mode doesn't swallow errors.
- `-f` is important — without it, curl exits 0 on HTTP 500.
- `--data` URL-encodes; use `--data-raw` or `--data-binary` for exact bodies.

## dog

**dog**


**Replaces:** `dig`, `nslookup` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `dog`; also distro-provided)

### Purpose
User-friendly DNS lookup with colourised output, JSON mode, native DoT/DoH support.

### Key flags
| Flag | Meaning |
|------|---------|
| `-1` / `--short` | Short output |
| `-J` / `--json` | JSON output |
| `-q NAME` | Query name (usually positional) |
| `-t TYPE` | Record type (`A`, `AAAA`, `MX`, `NS`, `TXT`, `CNAME`, …) |
| `-n NAMESERVER` | Specific nameserver |
| `--tcp` / `--udp` | Force transport |
| `--tls` | DNS-over-TLS (port 853) |
| `--https` | DNS-over-HTTPS |
| `-T` | Show TTL |
| `-Z` | Show response time |

### Examples
1. A record: `dog example.com`
2. MX records: `dog example.com MX`
3. Query 1.1.1.1 via DoH: `dog --https @1.1.1.1 anthropic.com`
4. JSON for scripting: `dog -J example.com | jaq '.responses[0].answers'`
5. Multiple types at once: `dog example.com A AAAA MX TXT`

### Gotchas
- Uses the system resolver by default — pass `@SERVER` for an explicit one.
- DoH URL format: `dog --https @https://cloudflare-dns.com/dns-query name`.

## gping

**gping**


**Replaces:** `ping` (visual) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `gping`)

### Purpose
Ping with a live graph. Multiple hosts plotted concurrently; can even graph exit latency of shell commands.

### Key flags
| Flag | Meaning |
|------|---------|
| `-4` / `-6` | Force IPv4 / IPv6 |
| `-s` | Simple output (no graph) |
| `-n N` | Samples per second |
| `-i SEC` / `--watch-interval SEC` | Ping interval |
| `-b N` / `--buffer N` | Seconds of history in buffer |
| `--cmd CMD` | Graph exit-time of CMD instead of ICMP |

### Examples
1. Ping a single host: `gping 1.1.1.1`
2. Compare two: `gping 8.8.8.8 1.1.1.1`
3. Graph a command's latency: `gping --cmd curl https://api.example.com/health`
4. Text-only: `gping -s example.com`

### Gotchas
- ICMP may require raw sockets → needs root or CAP_NET_RAW on Linux.
- Terminal must support 256 colours + UTF-8 for the graph.

## lychee

**lychee**


**Replaces:** link-checker scripts, `markdown-link-check` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `lychee`)

### Purpose
Fast async link checker for Markdown, HTML, RST, emails, arbitrary text. Suitable for CI.

### Key flags
| Flag | Meaning |
|------|---------|
| `-c FILE` / `--config FILE` | Config file (`lychee.toml`) |
| `-b URL` / `--base URL` | Base URL for relative links |
| `-r N` / `--retry-wait-time N` | Retry delay |
| `--max-retries N` | Retry count |
| `--accept CODES` | HTTP codes to accept (e.g. `200,204,403`) |
| `--exclude PATTERN` | Skip URLs matching regex |
| `--offline` | Skip remote links |
| `--include-mail` | Check `mailto:` |
| `--format FMT` | `markdown`, `json`, `detailed`, `compact` |
| `-o FILE` | Write report |
| `--cache` / `--no-progress` | CI helpers |

### Examples
1. Check a README: `lychee README.md`
2. Check a whole site: `lychee --offline ./book/`
3. CI-friendly JSON: `lychee --format json 'docs/**/*.md' -o links.json`
4. Ignore internal hosts: `lychee --exclude 'internal\.example\.com' docs/`

### Gotchas
- Default user agent may get rate-limited by big sites; set one via config.
- Use `--cache` + `--max-cache-age 1d` for CI runs to avoid hammering upstream.

## monolith

**monolith**


**Replaces:** `wget --page-requisites --convert-links`, browser "Save Page As" | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `monolith`)

### Purpose
Saves a complete web page as a single self-contained HTML file (CSS/JS/images/fonts inlined as data URIs).

### Key flags
| Flag | Meaning |
|------|---------|
| `-o FILE` / `--output FILE` | Output path (`-` for stdout) |
| `-a` / `--no-audio` | Strip audio |
| `-v` / `--no-video` | Strip video |
| `-i` / `--no-images` | Strip images |
| `-j` / `--no-js` | Strip JavaScript |
| `-s` / `--silent` | Silent |
| `-F` / `--isolate` | CSP that blocks network requests in saved file |
| `-M` / `--no-metadata` | Strip metadata comment |
| `-u UA` / `--user-agent UA` | Custom User-Agent |
| `-t SEC` / `--timeout SEC` | Network timeout |

### Examples
1. Archive a page: `monolith https://example.com/article -o article.html`
2. Sanitised (no scripts, no network): `monolith -F -j https://example.com/page -o safe.html`
3. Text-only: `monolith -i -j -v -a https://example.com -o text.html`

### Gotchas
- JavaScript-rendered sites capture the initial HTML only; for SPAs, use headless-browser-backed tools.
- `-F --no-js --no-metadata --isolate` is a good default for long-term archiving.

## rustscan

**rustscan**


**Replaces:** `nmap` (fast-scan front-end) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rustscan`)

### Purpose
Extremely fast TCP port scanner; typically pipes into `nmap` for deeper enumeration. **Only scan hosts you have explicit authorisation to test.**

### Key flags
| Flag | Meaning |
|------|---------|
| `-a HOST` / `--addresses HOST` | Target(s) (CIDR, comma list, or file) |
| `-p PORTS` / `--ports PORTS` | Specific ports (e.g. `80,443,8000-9000`) |
| `-r RANGE` / `--range RANGE` | Port range (default `1-65535`) |
| `-u LIMIT` / `--ulimit LIMIT` | File-descriptor limit |
| `-b N` / `--batch-size N` | Parallel sockets |
| `-t MS` / `--timeout MS` | Per-port timeout |
| `--scan-order RANDOM\|SERIAL` | Scan order |
| `-g` / `--greppable` | Plain output |
| `--accessible` | Screen-reader-friendly |
| `--` | Pass remaining flags to `nmap` |

### Examples
1. Scan a host then hand off to nmap for service detection: `rustscan -a 10.0.0.1 -- -sV -A`
2. Limit to common ports: `rustscan -a example.com -p 22,80,443,8080`
3. Subnet sweep: `rustscan -a 192.168.1.0/24 -b 5000`
4. Grep-able output: `rustscan -a host -g`

### Gotchas
- Extremely aggressive defaults can trigger IDS alerts.
- File-descriptor limit: bump with `ulimit -n 65535` or the `-u` flag.
- Running against infrastructure you don't own or administer is typically illegal — always get authorisation.

## sniffglue

**sniffglue**


**Replaces:** `tcpdump` (partial) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `sniffglue`)

### Purpose
Secure, multithreaded packet sniffer. Parses common protocols (Ethernet, IPv4/6, TCP, UDP, DNS, TLS, HTTP) with sandboxed workers.

### Key flags
| Flag | Meaning |
|------|---------|
| `-d DEV` | Capture device (e.g. `eth0`) |
| `-p PCAP` | Read from pcap file |
| `-v` | Verbose |
| `-n N` | Stop after N packets |
| `--promisc` | Promiscuous mode |
| `--insecure-disable-seccomp` | Disable sandbox (debugging only) |

### Examples
1. Sniff an interface: `sudo sniffglue -d eth0`
2. Read a capture: `sniffglue -p trace.pcap`
3. Just first 100 packets: `sudo sniffglue -d wlan0 -n 100`

### Gotchas
- Needs `CAP_NET_RAW` + `CAP_NET_ADMIN` (or root) to open the socket.
- Not a `tcpdump` BPF-filter replacement — for precise captures, still use `tcpdump` / `tshark`.

## trippy

**trippy (trip)**


**Replaces:** `traceroute`, `mtr` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `trippy`)

### Purpose
Network diagnostic TUI combining `traceroute` and `mtr`. ICMP/UDP/TCP probes, geolocation, DNS, IPv4/6.

### Key flags
| Flag | Meaning |
|------|---------|
| `-p PROTO` / `--protocol PROTO` | `icmp`, `udp`, `tcp` |
| `-P PORT` | Destination port (UDP/TCP) |
| `-L N` / `--multipath-strategy N` | ECMP detection |
| `-i SEC` / `--min-round-duration SEC` | Round interval |
| `-m N` / `--max-ttl N` | Max hops |
| `-z` / `--tui-refresh-rate` | UI refresh |
| `-r RESOLVER` | `system`, `resolv`, `google`, `cloudflare` |
| `--report-cycles N` | Non-TUI mode: run N cycles and print report |
| `--report-format FMT` | `pretty`, `csv`, `json`, `markdown`, `silent` |
| `-4` / `-6` | Force IPv4/6 |

### Examples
1. Interactive TUI: `trip example.com`
2. TCP trace to HTTPS port: `trip example.com -p tcp -P 443`
3. CI-friendly JSON report, 10 cycles: `trip example.com --report-cycles 10 --report-format json`
4. Multi-host (TUI tabs): `trip example.com cloudflare.com`

### Gotchas
- ICMP/UDP/TCP modes hit different path discovery semantics — results can differ.
- Raw sockets again → root or CAP_NET_RAW.
- `trip` and `trippy` are the same binary on most distros.

## wget2

**wget2**


**Replaces:** `wget` | **Language:** ⚠️ C | **Install:** via `spacecraft-missing-pkg` (distro-provided)

### Purpose
Successor to wget. Multithreaded HTTP/2 downloader, better for large mirrors and batch fetches.

### Key flags
| Flag | Meaning |
|------|---------|
| `-O FILE` | Save to FILE |
| `-P DIR` | Save under DIR |
| `-c` | Resume partial |
| `-r` | Recursive |
| `-np` | No parent (limit recursion upward) |
| `-nd` | No directory structure |
| `-l N` | Recursion depth |
| `--threads N` | Parallel connections (wget2-specific) |
| `-k` / `--convert-links` | Rewrite links for local viewing |
| `-U UA` | User-Agent |
| `--tries N` | Retry count |

### Examples
1. Parallel download: `wget2 --threads 8 https://big.example.com/file.iso`
2. Mirror a docs site: `wget2 -r -np -k -P docs/ https://example.com/docs/`
3. Resume interrupted: `wget2 -c URL`

### Gotchas
- Not a 100% flag-compat drop-in for wget — review scripts.
- For single ad-hoc requests, `curl -LO` is usually simpler.

## xh

**xh**


**Replaces:** `curl` (interactive/API work) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `xh`)

### Purpose
Friendly, fast HTTP client with HTTPie-style syntax. For ad-hoc API probing, prefer `xh`; keep `curl` for cross-system shell scripts.

### Syntax
```
xh [METHOD] URL [REQUEST_ITEMS...]
```
Request items:
- `name=value` → JSON field
- `name:=value` → raw JSON (numbers, booleans, arrays)
- `name==value` → query string
- `name:value` → header
- `name@file` → file upload

### Key flags
| Flag | Meaning |
|------|---------|
| `-f` | Form-encode body |
| `-j` | Force JSON body (default when body items present) |
| `-a USER:PASS` | Basic auth |
| `-A bearer -a TOKEN` | Bearer auth |
| `-h` | Only print response headers |
| `-b` | Only print response body |
| `-p PRINT` | `H`=request headers, `B`=request body, `h`=response headers, `b`=response body |
| `--follow` | Follow redirects |
| `--verify=no` | Skip TLS verification |
| `-d` | Download mode (streaming to file) |
| `-o FILE` | Write body to FILE |
| `-S` | Stream response |

### Examples
1. GET JSON: `xh https://api.github.com/repos/UnbreakableMJ/Understand-Anything`
2. POST JSON body: `xh POST api.example.com/users name=alice age:=30 active:=true`
3. Headers + query: `xh api.com/search q==rust 'Authorization:Bearer $TOKEN'`
4. File upload: `xh POST api.com/upload file@/tmp/data.csv`
5. Download: `xh -d https://example.com/release.tar.gz`
6. Follow redirects, show everything: `xh --follow -p HhBb example.com`

### Gotchas
- `:=` vs `=`: use `:=` for non-string JSON values.
- No `-X` method flag — method goes first positionally.
- `xh` colourises output for TTYs; pipe via `--pretty=none` for scripts.
