# Multimedia

## ffmpeg

**ffmpeg**


**Replaces:** — (Spacecraft Software-sanctioned toolkit) | **Language:** ⚠️ C | **Install:** via `spacecraft-missing-pkg` (distro-provided)

### Purpose
The multimedia swiss-army knife. No Rust replacement comes close — keep `ffmpeg`. Pair it with `rav1e` / `gifski` / `oxipng` where specific output formats benefit.

### Key flags
| Flag | Meaning |
|------|---------|
| `-i FILE` | Input |
| `-c:v CODEC` / `-c:a CODEC` | Video / audio codec |
| `-b:v RATE` / `-b:a RATE` | Bitrate |
| `-crf N` | Constant rate factor (x264/x265) |
| `-r N` | Frame rate |
| `-s WxH` / `-vf "scale=W:H"` | Resize |
| `-ss T` / `-to T` / `-t DUR` | Seek / end / duration |
| `-an` / `-vn` / `-sn` | Drop audio / video / subs |
| `-map 0:v:0 -map 0:a:0` | Stream selection |
| `-f FMT` | Force format |
| `-y` | Overwrite output |
| `-threads N` | Parallelism |

### Examples
1. Convert MP4 → WebM: `ffmpeg -i in.mp4 -c:v libvpx-vp9 -c:a libopus out.webm`
2. Trim: `ffmpeg -ss 00:00:10 -t 30 -i in.mp4 -c copy clip.mp4`
3. Extract audio: `ffmpeg -i in.mp4 -vn -c:a copy out.m4a`
4. Burn subtitles: `ffmpeg -i in.mp4 -vf "subtitles=sub.srt" -c:a copy out.mp4`
5. GIF via palette (before gifski was common): `ffmpeg -i in.mp4 -vf "fps=15,scale=480:-1" out.gif`
6. Concat losslessly: `ffmpeg -f concat -safe 0 -i list.txt -c copy joined.mp4`
7. Pipe to rav1e: `ffmpeg -i in.mp4 -f yuv4mpegpipe - | rav1e - -o out.ivf`

### Gotchas
- `-ss` before `-i` = fast seek (keyframe); after `-i` = accurate but slow.
- `-c copy` is lossless but requires compatible container + codec.
- Mixing input and output flags by position is error-prone — always annotate.

## gifski

**gifski**


**Replaces:** `ffmpeg`-based GIF pipelines, `convert` (ImageMagick) for GIF | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `gifski`)

### Purpose
High-quality GIF encoder based on the pngquant palette generator. Produces smaller, better-looking GIFs from video or PNG frames.

### Key flags
| Flag | Meaning |
|------|---------|
| `-o FILE` / `--output FILE` | Output GIF |
| `--fps N` | Frames per second |
| `--quality N` | 1–100 |
| `-W N` / `--width N` | Resize width |
| `-H N` / `--height N` | Resize height |
| `--fast` | Prefer speed |
| `--repeat N` | Loop count (0 = infinite) |
| `--motion-quality N` | Per-frame dither quality |
| `--lossy-quality N` | Lossy compression level |

### Examples
1. From frames: `gifski -o out.gif --fps 30 frames/*.png`
2. From video via ffmpeg: `ffmpeg -i in.mp4 -vf "fps=20,scale=720:-1" -f image2pipe -vcodec png - | gifski -o out.gif --fps 20 -`
3. Resize + loop: `gifski -W 480 --repeat 0 -o loop.gif *.png`

### Gotchas
- Frames must be supplied as PNGs or via pipe — no direct video input.
- Large frame counts need lots of RAM.

## mpv

**mpv**


**Replaces:** — (Spacecraft Software-sanctioned player) | **Language:** ⚠️ C | **Install:** via `spacecraft-missing-pkg` (distro-provided)

### Purpose
Versatile, high-quality command-line media player. No Rust replacement is as capable; keep `mpv`.

### Key flags
| Flag | Meaning |
|------|---------|
| `--fs` | Fullscreen |
| `--loop=inf` / `--loop-file=inf` | Loop |
| `--shuffle` | Shuffle playlist |
| `--speed=N` | Playback speed |
| `--start=POS` / `--end=POS` | Trim range |
| `--no-audio` / `--no-video` | Disable stream |
| `--sid=N` / `--aid=N` | Subtitle / audio track |
| `--sub-file=FILE` | External subtitle |
| `--ytdl-format=FMT` | yt-dlp format |
| `--screenshot-format=PNG` | Screenshot format |
| `-o FILE` / `--o=FILE` | Dump to file (with `--o-format`) |

### Examples
1. Play a file: `mpv movie.mkv`
2. Play a YouTube URL: `mpv https://youtu.be/ID`
3. Loop a clip: `mpv --loop-file=inf clip.mp4`
4. Specific subtitle: `mpv --sub-file=en.srt movie.mkv`
5. Audio-only background: `mpv --no-video podcast.mp3`
6. Extract a clip: `mpv --start=00:01:00 --end=00:02:00 --o=clip.mp4 input.mp4`

### Gotchas
- YouTube support depends on `yt-dlp` being on PATH and current.
- Input config: `~/.config/mpv/input.conf`; main config: `mpv.conf`.

## ncspot

**ncspot**


**Replaces:** Spotify GUI (terminal alternative) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `ncspot`)

### Purpose
TUI Spotify client. Requires a Spotify Premium account.

### Launch
```
ncspot
```

### Key bindings
| Key | Action |
|-----|--------|
| `Space` | Play/pause |
| `n` / `p` | Next / previous track |
| `s` | Search |
| `q` | Queue view |
| `l` | Library |
| `Enter` | Select |
| `/` | Search within view |
| `Shift+Q` | Quit |
| `?` | Help |

### Examples
1. Launch: `ncspot`
2. Set up MPRIS (control from media keys): enable `use_mpris = true` in config
3. Playback control from another terminal: `dbus-send` to the MPRIS interface, or use `playerctl`

### Gotchas
- First launch prompts for Spotify credentials; stored in `$XDG_CONFIG_HOME/ncspot/`.
- Premium-only — free accounts hit API errors.
- Config for keybindings and theme: `$XDG_CONFIG_HOME/ncspot/config.toml`.

## oxipng

**oxipng**


**Replaces:** `optipng`, `pngcrush` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `oxipng`)

### Purpose
Multithreaded, lossless PNG optimiser. Strips metadata, tries multiple filter/deflate strategies.

### Key flags
| Flag | Meaning |
|------|---------|
| `-o N` | Optimisation level 0–6 (default 2) |
| `-Z` | Zopfli compression (slower, smaller) |
| `--strip safe` / `all` | Metadata stripping |
| `-r` | Recurse into directories |
| `-p` / `--preserve` | Preserve timestamps |
| `--alpha` | Optimise alpha pre-multiplication |
| `-t N` / `--threads N` | Thread count |
| `--interlace 0` / `1` | Set PNG interlacing |

### Examples
1. Optimise in place: `oxipng -o 4 image.png`
2. Strip all metadata: `oxipng --strip all *.png`
3. Recursive, Zopfli, max compression: `oxipng -r -Z -o max assets/`
4. Keep timestamps: `oxipng -p -o 3 *.png`

### Gotchas
- In-place by default — make a backup or use `-P SUFFIX`.
- `-Z` can be 10× slower than `-o 4` for small gains.

## radio-browser

**radio-browser-rust**


**Replaces:** — (dedicated internet radio CLI) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `radio-browser`)

### Purpose
CLI to search and play internet radio stations from the radio-browser.info community database.

### Key commands
| Command | Meaning |
|---------|---------|
| `radio-browser search QUERY` | Search stations |
| `radio-browser play STATION` | Play by name/UUID |
| `radio-browser top` | Top-voted stations |
| `radio-browser countries` | Browse by country |
| `radio-browser tags` | Browse by tag |

### Examples
1. Search by name: `radio-browser search "BBC"`
2. Play a station: `radio-browser play "BBC Radio 4"`
3. Find Bahraini stations: `radio-browser search --country BH`

### Gotchas
- Needs `mpv` or similar on PATH for playback.
- Some streams are geoblocked.

## rav1e

**rav1e**


**Replaces:** AV1 encoders (libaom, SVT-AV1 — alternative) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `rav1e`; also distro-provided)

### Purpose
Fast, memory-safe AV1 video encoder. Outputs IVF or raw Annex-B. Pair with `ffmpeg` for container muxing.

### Key flags
| Flag | Meaning |
|------|---------|
| `-o FILE` | Output path |
| `-s N` / `--speed N` | 0 (slowest/best) — 10 (fastest) |
| `-q N` / `--quantizer N` | Constant quantizer (0–255) |
| `--tile-rows N` / `--tile-cols N` | Tiling |
| `--threads N` | Thread count |
| `--limit N` | Encode only N frames |
| `--output-invalid-frames` | Include invalid frames (debug) |
| `--first-pass FILE` / `--second-pass FILE` | Two-pass |

### Examples
1. Encode a Y4M to AV1 IVF: `rav1e -s 6 -q 100 input.y4m -o out.ivf`
2. Pipe from ffmpeg: `ffmpeg -i in.mp4 -f yuv4mpegpipe - | rav1e - -o out.ivf`
3. Mux AV1 + Opus audio: `ffmpeg -i out.ivf -i audio.opus -c copy out.mkv`
4. Fastest reasonable: `rav1e -s 9 -q 130 in.y4m -o out.ivf`

### Gotchas
- Input must be raw Y4M/YUV — use `ffmpeg` for any other format.
- Speed 0–3 is impractical for anything beyond short clips.
- For HEVC/H.264 output, stick with `ffmpeg` + `x264`/`x265`.

## termusic

**termusic**


**Replaces:** `cmus`, `ncmpcpp` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crates: `termusic` + `termusic-server`)

### Purpose
Local-file TUI music player with album art support, MPRIS, gapless playback. Client-server architecture.

### Launch
```
termusic-server &    # start backend
termusic             # TUI client
```

### Key bindings
| Key | Action |
|-----|--------|
| `Tab` | Switch library / playlist pane |
| `Space` / `Enter` | Play selected |
| `n` / `N` | Next / previous |
| `p` | Pause |
| `l` / `h` | Seek forward / back |
| `+` / `-` | Volume |
| `q` | Quit |
| `?` | Help |

### Examples
1. Set music dir: edit `$XDG_CONFIG_HOME/termusic/config.toml` → `music_dir`
2. Start playback from CLI: `termusic --server-autostart`

### Gotchas
- Requires ALSA/PulseAudio/PipeWire backend.
- Album art requires a Kitty/WezTerm-capable terminal (same as `viu`).

## viu

**viu**


**Replaces:** image viewers in terminal (feh in-terminal fallback) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `viu`)

### Purpose
View images directly in the terminal using kitty/iTerm2/sixel graphics protocols, or falls back to half-block Unicode.

### Key flags
| Flag | Meaning |
|------|---------|
| `-w N` / `--width N` | Width in cells |
| `-h N` / `--height N` | Height in cells |
| `-t` / `--transparent` | Respect alpha |
| `-s` / `--static` | Don't animate GIFs |
| `-f N` / `--frame-rate N` | GIF playback FPS |
| `-n` / `--once` | Play animation once |
| `-r` / `--recursive` | Recurse into directories |
| `-b` / `--blocks` | Force unicode half-block mode |

### Examples
1. Show an image: `viu screenshot.png`
2. Fixed width: `viu -w 60 photo.jpg`
3. Browse images in a dir: `viu -r photos/`
4. Static preview of a GIF: `viu -s anim.gif`

### Gotchas
- Best results in kitty/WezTerm/Ghostty; other terminals fall back to half-blocks.
- Very large images get slow in unicode mode — resize first with `oxipng`/`ffmpeg`.

## yt-dlp

**yt-dlp**


**Replaces:** `youtube-dl`, all youtube-dl forks | **Language:** 🐍 Python | **Install:** via `spacecraft-missing-pkg` (PyPI package: `yt-dlp`; also distro-provided)

### Purpose
Feature-rich media downloader for YouTube and 1000+ sites. Gold standard; no Rust equivalent comes close.

### Key flags
| Flag | Meaning |
|------|---------|
| `-o TEMPLATE` | Output filename template |
| `-f FORMAT` | Format selector (`best`, `bestvideo+bestaudio`, `137+140`, etc.) |
| `-F URL` | List available formats |
| `-x` | Extract audio |
| `--audio-format FMT` | `mp3`, `m4a`, `opus`, `flac` |
| `--audio-quality N` | 0 (best) — 9 |
| `-a FILE` | Read URLs from file |
| `-i` | Ignore errors |
| `--embed-subs` / `--embed-thumbnail` | Embed |
| `--write-sub` / `--sub-langs en,de` | Write subs |
| `--cookies-from-browser firefox` | Use browser cookies |
| `--playlist-items 1-5` | Range |
| `-q` / `-v` | Quiet / verbose |
| `--download-archive FILE` | Skip already-downloaded |

### Examples
1. Best video+audio: `yt-dlp -f "bv*+ba/b" URL`
2. MP3 audio: `yt-dlp -x --audio-format mp3 --audio-quality 0 URL`
3. List formats first: `yt-dlp -F URL`
4. Named output: `yt-dlp -o "%(title)s.%(ext)s" URL`
5. Channel with archive (avoid redownloading): `yt-dlp --download-archive seen.txt -o "%(channel)s/%(title)s.%(ext)s" CHANNEL_URL`
6. With browser cookies for members-only content: `yt-dlp --cookies-from-browser firefox URL`

### Gotchas
- Keep yt-dlp **updated** — site extractors break often. An ephemeral run
  (`uvx yt-dlp …`, see `spacecraft-missing-pkg`) always resolves the current
  release, which sidesteps the staleness problem entirely; a pinned install
  needs updating through whatever provisioned it.
- `ffmpeg` required for format merging and audio extraction.
- Rate-limiting: `--sleep-interval 2 --max-sleep-interval 5` for politeness.
