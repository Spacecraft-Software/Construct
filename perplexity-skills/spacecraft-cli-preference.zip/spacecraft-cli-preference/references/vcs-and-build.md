# Version Control & Build

## cargo-update

**cargo-update (cargo install-update)**


**Replaces:** manual `cargo install --force <each-binary>` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `cargo-update`)

### Purpose
Subcommand that updates binaries installed via `cargo install` to their latest crates.io/git versions.

### Key commands
| Command | Meaning |
|---------|---------|
| `cargo install-update -l` | List installed binaries + upstream versions |
| `cargo install-update -a` | Update all outdated |
| `cargo install-update PKG…` | Update specific |
| `cargo install-update -g` | Include git-sourced installs |
| `cargo install-update-config PKG --set-...` | Per-package pin/feature config |

### Examples
1. What needs updating: `cargo install-update -l`
2. Update everything: `cargo install-update -a`
3. Include git installs: `cargo install-update -ag`
4. Pin to a version: `cargo install-update-config ripgrep --set-version 14`

### Gotchas
- Some binaries built from git need explicit `-g` every time.
- `cargo install-update-config` writes state to `.crates2.json`.

## cpx

**cpx**


**Replaces:** competitive-programming helper scripts | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `cpx`)

### Purpose
Scaffolds competitive-programming contest directories, fetches problem statements/test cases from judges, runs/tests your solutions locally.

### Typical workflow
| Command | Meaning |
|---------|---------|
| `cpx new PROBLEM_URL` | Create directory, fetch tests |
| `cpx test` | Run sample tests against your solution |
| `cpx submit` | Submit (where supported) |
| `cpx lang LANG` | Switch language template |

### Examples
1. Start a new Codeforces problem: `cpx new https://codeforces.com/problemset/problem/1/A`
2. Run sample tests: `cpx test`
3. Switch to Rust template: `cpx lang rust`

### Gotchas
- Judge-specific scraping can break when sites change HTML — keep cpx updated
  through whatever provisioned it (see `spacecraft-missing-pkg`).
- Authentication cookies/credentials live in a plain config file; secure the directory.

## gitui

**gitui**


**Replaces:** `git` (interactive) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `gitui`)

### Purpose
Blazing-fast, keyboard-driven terminal UI for git. Stage hunks, view diffs, manage branches/stashes, resolve conflicts — without leaving the terminal.

### Launch
```
gitui              # current repo
gitui -d PATH      # repo at PATH
gitui -t THEME     # preset theme
```

### Key bindings
| Key | Action |
|-----|--------|
| `1`–`5` | Switch tabs (Status, Log, Files, Stash, Stashing) |
| `Tab` | Move between panels |
| `Enter` | Stage/unstage |
| `s`/`u` | Stage / unstage hunk |
| `c` | Commit |
| `P`/`p` | Push / pull |
| `d` | Diff |
| `r` | Reset |
| `b` | Branch list |
| `B` | Blame |
| `h`/`?` | Help |
| `q` | Quit |

### Examples
1. Open in a project: `gitui`
2. Theme switching: `gitui -t mocha.ron`
3. Launch on a specific repo: `gitui -d ~/code/spacecraft-rust-guidelines`

### Gotchas
- Config/theme path: `$XDG_CONFIG_HOME/gitui/` (key_bindings.ron, theme.ron).
- No interactive rebase editor yet — drop to `git rebase -i` for that.
- Terminal must support Unicode + 256 colours for icons/theme.

## gitway

**gitway**


**Replaces:** `ssh` (for Git transport to GitHub/GHE) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (Spacecraft Software default; built from `gitway-cli` in `github.com/Spacecraft-Software/Gitway`)

### Purpose
Purpose-built SSH transport client for Git operations against GitHub and GitHub
Enterprise Server. Unlike general-purpose `ssh`, Gitway pins GitHub's host-key
fingerprints (no TOFU), searches for keys in a predictable order, and behaves
identically on Linux, macOS, and Windows. Drop-in for `GIT_SSH_COMMAND` and
`core.sshCommand`. Does **not** replace `ssh` for general SSH use (shells,
tunneling, forwarding) — only for Git's SSH transport.

### Key flags
| Flag | Meaning |
|------|---------|
| `-i, --identity <FILE>` | Path to SSH private key |
| `--cert <FILE>` | OpenSSH certificate alongside the key |
| `-p, --port <PORT>` | SSH port (default: 22) |
| `-v, --verbose` | Debug logging to stderr |
| `--test` | Verify connectivity; print GitHub banner |
| `--install` | Register as `core.sshCommand` in global Git config |
| `--insecure-skip-host-check` | Danger: skip host-key verification |

### Examples
1. Register Gitway as the global Git SSH command
   `gitway --install`
2. Verify connectivity to GitHub
   `gitway --test`
3. Use a specific key
   `gitway --identity ~/.ssh/id_ed25519_github github.com git-upload-pack 'org/repo.git'`
4. Per-operation override (POSIX/Bash)
   `GIT_SSH_COMMAND=gitway git clone git@github.com:org/repo.git`
5. Per-operation override (Nushell)
   `$env.GIT_SSH_COMMAND = "gitway"; git clone git@github.com:org/repo.git`
6. Target a GHE instance
   `gitway --port 22 ghe.corp.example.com git-upload-pack 'org/repo.git'`

### Gotchas
- **GitHub/GHE only.** Not a general `ssh` replacement — will not connect to
  arbitrary hosts. Keep `ssh` for shell sessions, port-forwarding, tunnels.
- **GHE requires `~/.config/gitway/known_hosts`** populated with SHA-256
  fingerprints in OpenSSH `known_hosts` format. Retrieve via
  `ssh-keyscan -t ed25519 <host> | ssh-keygen -lf -`.
- **Key discovery order is fixed:** `--identity` → `~/.ssh/id_ed25519` →
  `~/.ssh/id_ecdsa` → `~/.ssh/id_rsa` → `SSH_AUTH_SOCK` agent.
- **Host-key pinning aborts on mismatch.** If GitHub rotates keys, update Gitway
  rather than bypassing with `--insecure-skip-host-check`.
- **Library crate available:** `gitway-lib` for embedding programmatic Git
  transport in Rust projects.
- **Repo:** `github.com/Spacecraft-Software/Gitway` — check there for current fingerprints
  and MSRV.

## jujutsu

**jujutsu (jj)**


**Replaces:** `git` (alternative VCS front-end) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `jj-cli` (build locked))

### Purpose
Git-compatible distributed VCS with first-class conflict handling, anonymous branches, and reversible operations. Works against existing git repos (colocated or standalone backend).

### Key commands
| Command | Meaning |
|---------|---------|
| `jj git init --colocate` | New repo alongside `.git` |
| `jj git clone URL` | Clone |
| `jj status` / `jj st` | Working-copy status |
| `jj log` | Graph of commits |
| `jj describe -m "MSG"` | Set message of current change |
| `jj new` | Start a new empty change on current parent |
| `jj new REV` | New change on top of REV |
| `jj squash` | Fold current change into parent |
| `jj rebase -d REV` | Rebase current branch onto REV |
| `jj abandon` | Drop current change |
| `jj op log` | Operation log (undo!) |
| `jj undo` | Revert the last `jj` op |
| `jj git push` | Push bookmarks to origin |

### Examples
1. Initialize inside an existing git repo: `cd repo && jj git init --colocate`
2. Start a fresh change: `jj new -m "Add config crate"`
3. View the log: `jj log -r 'all()' --limit 20`
4. Amend + rebase: `jj describe -m "New msg"` then `jj rebase -d main`
5. Undo a mistake: `jj op log` → `jj undo`

### Gotchas
- The "current change" is the working copy itself — no explicit `git add`/`commit` loop.
- Bookmarks (jj's named refs) are separate from git branches; sync via `jj git push`/`fetch`.
- Some git hosting features (PR UIs) still assume git branches — use `jj bookmark` to name your work before pushing.

## just

**just**


**Replaces:** `make` (for task running) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `just`)

### Purpose
Modern command runner. `Justfile` syntax is cleaner than Make's, no tab/space traps, first-class dependencies, `.env` support.

### Justfile basics
```make
default: build test

build:
    cargo build --release

test:
    cargo nextest run

fmt:
    cargo fmt --all

clean:
    cargo clean
    rm -rf dist/

# With parameter
release version:
    cargo publish -p {{version}}
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-l` / `--list` | List recipes |
| `-s RECIPE` / `--show RECIPE` | Show recipe source |
| `-n` / `--dry-run` | Print commands, don't execute |
| `--choose` | Interactive recipe picker (needs `fzf`) |
| `-f FILE` / `--justfile FILE` | Use non-default Justfile |
| `-d DIR` / `--working-directory DIR` | Run from DIR |
| `--evaluate` | Dump variables + exit |
| `--set NAME VAL` | Override variable |

### Examples
1. Run default recipe: `just`
2. List recipes: `just -l`
3. Run a parameterised recipe: `just release 1.2.0`
4. Pick interactively: `just --choose`
5. Dry run: `just -n build`

### Gotchas
- Indentation is either tabs OR spaces consistently — mixing breaks parse.
- Recipes run in a fresh shell each line unless you use `\` to chain.
- Uses `sh` by default; switch with `set shell := ["nu", "-c"]` or `["ion", "-c"]` at the top of the Justfile.

## lorri

**lorri**


**Replaces:** manual `nix-shell` invocations | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (nixpkgs: `lorri`; upstream crate: `lorri`)

### Purpose
Daemon that watches `shell.nix` / `default.nix` and keeps a cached build environment hot. Integrates with `direnv` for automatic per-directory shell activation.

### Setup
1. Provision it via `spacecraft-missing-pkg` — on a declaratively managed host
   that means `home.packages = [ pkgs.lorri ];` (or the `services.lorri` module),
   not an imperative profile install.
2. Start the daemon: `systemctl --user enable --now lorri.service` (or use the launchd/OpenRC unit).
3. In each project: `echo "eval \"\$(lorri direnv)\"" > .envrc && direnv allow`

### Key commands
| Command | Meaning |
|---------|---------|
| `lorri init` | Create `shell.nix` + `.envrc` scaffolding |
| `lorri daemon` | Run the watcher (usually as user unit) |
| `lorri watch` | One-shot watch + build |
| `lorri direnv` | Print direnv-compatible shell snippet |
| `lorri gc` | GC old build roots |

### Examples
1. New project: `lorri init && direnv allow`
2. Force rebuild: `touch shell.nix` (daemon picks it up)
3. Clear build roots: `lorri gc`

### Gotchas
- Requires Nix with flakes or classic; on flakes projects prefer `direnv` + `nix develop` via `use flake` in `.envrc`.
- Lorri's upstream has slowed — newer Bravais work may prefer plain `direnv + nix-direnv`.

## podman

**podman**


**Replaces:** `docker` | **Language:** 🐹 Go | **Install:** via `spacecraft-missing-pkg` (distro-provided)

### Purpose
Daemonless, rootless, Docker-CLI-compatible container engine. Runs OCI containers/pods without a privileged daemon. Spacecraft Software-sanctioned for container workflows.

### Key commands (Docker-compat)
| Command | Meaning |
|---------|---------|
| `podman pull IMAGE` | Fetch image |
| `podman run [-it] IMAGE CMD` | Run container |
| `podman ps [-a]` | List containers |
| `podman images` | List images |
| `podman build -t NAME .` | Build from Containerfile/Dockerfile |
| `podman exec -it CTR CMD` | Shell into running container |
| `podman logs CTR` | View logs |
| `podman rm CTR` / `podman rmi IMAGE` | Delete |
| `podman pod create --name POD` | Pods (multiple containers, shared netns) |
| `podman generate systemd` | Emit systemd unit for a container |
| `podman compose up` | Docker-compose-compatible (needs plugin or `podman-compose`) |

### Examples
1. Run an Alpine shell: `podman run --rm -it docker.io/alpine sh`
2. Build image: `podman build -t spacecraft-software/ferrocast:dev .`
3. Detached with port mapping: `podman run -d -p 8080:80 nginx:alpine`
4. Generate a user systemd unit: `podman generate systemd --new --files --name myctr`
5. Rootless volume mount: `podman run -v "$PWD":/app:Z image`

### Gotchas
- Rootless networking uses `slirp4netns`/`pasta` — slightly different perf/port binding than rootful Docker.
- SELinux systems need `:z` (shared) or `:Z` (private) volume labels.
- `alias docker=podman` works for most scripts, but `docker.sock` clients need `podman system service`.

## rustup

**rustup**


**Replaces:** manual Rust toolchain management | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream: <https://rustup.rs>)

### Purpose
Official Rust toolchain multiplexer. Manages stable/beta/nightly channels, targets, components (rustfmt, clippy, rust-analyzer).

### Key commands
| Command | Meaning |
|---------|---------|
| `rustup update` | Update all installed toolchains |
| `rustup default CHANNEL` | Set default (`stable`, `beta`, `nightly`, `1.78.0`) |
| `rustup toolchain install CHANNEL` | Install a toolchain |
| `rustup target add TARGET` | Add compilation target (e.g. `wasm32-unknown-unknown`) |
| `rustup component add NAME` | Add component (`clippy`, `rustfmt`, `rust-src`, `rust-analyzer`) |
| `rustup show` | Show active toolchain |
| `rustup override set NIGHTLY` | Pin toolchain for current directory |
| `rustup run CHANNEL CMD` | Run CMD with a specific toolchain |
| `rustup self update` | Update rustup itself |

### Examples
1. Fresh bootstrap: `curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh`
2. Add WASM target: `rustup target add wasm32-unknown-unknown`
3. Use nightly in this directory only: `rustup override set nightly`
4. Add clippy + rust-analyzer: `rustup component add clippy rust-analyzer`
5. Run a one-off nightly build: `rustup run nightly cargo build`

### Gotchas
- `rust-toolchain.toml` in a repo will override CLI defaults automatically — preferred for per-project pinning.
- `rustup self update` is disabled on package-manager installations (apt, brew, nix) — use the package manager.
