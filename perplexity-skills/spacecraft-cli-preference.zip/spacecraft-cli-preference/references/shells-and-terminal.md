# Shells & Terminal

## atuin

**atuin**


**Replaces:** native shell history, `fc`, reverse-i-search (Ctrl+R) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `atuin`)

### Purpose
SQLite-backed shell history with fuzzy full-text search, per-directory/host/session context, optional end-to-end encrypted sync across machines.

### Setup
```
atuin init SHELL >> ~/.SHELLrc   # or source directly
atuin import auto                # import existing history
atuin register / atuin login     # optional sync
```
Supports: Bash, Zsh, Fish, Nushell, Xonsh.

### Key commands
| Command | Meaning |
|---------|---------|
| `atuin search [QUERY]` | Search (opens TUI if no query) |
| `atuin stats` | Usage stats |
| `atuin sync` | Sync to server |
| `atuin status` | Status + sync health |
| `atuin import SHELL` | Import legacy history |
| `atuin history list` | Scriptable listing |
| `atuin server` | Self-host sync server |

### Key flags (search)
| Flag | Meaning |
|------|---------|
| `--cwd DIR` | Filter by working directory |
| `--session ID` | Filter by shell session |
| `--before` / `--after TIME` | Time range |
| `--limit N` | Max results |
| `--format FMT` | `{command}`, `{time}`, `{exit}`, etc. |

### Examples
1. Interactive search (replaces Ctrl+R): `atuin search`
2. Show commands I've run here before: `atuin search --cwd "$PWD"`
3. Stats for last week: `atuin stats --after 1week`
4. Self-host sync: run `atuin server start` on a VPS

### Gotchas
- On first run, Ctrl+R is rebound — set `disable_up_arrow=true` in `config.toml` if you prefer.
- Sync encrypts data client-side, but recovery requires the key saved at registration.
- DB: `$XDG_DATA_HOME/atuin/history.db` — back up.

## brush

**brush**


**Replaces:** `bash` (compatible) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `brush-shell`)

### Purpose
Memory-safe, Bash-compatible shell in Rust. Aims to run existing Bash scripts unmodified while being a daily interactive shell.

### Launch
```
brush                 # interactive
brush script.sh       # run bash script
brush -c "CMD"        # single command
```

### Key flags
| Flag | Meaning |
|------|---------|
| `-c CMD` | Execute CMD and exit |
| `-i` | Force interactive |
| `--noprofile` / `--norc` | Skip startup files |
| `--posix` | POSIX mode |
| `-x` | Trace execution |

### Examples
1. Drop-in script execution: `brush ./install.sh`
2. One-liner: `brush -c 'for i in 1 2 3; do echo $i; done'`
3. Use as login shell: add path to `/etc/shells`, then `chsh -s $(which brush)`

### Gotchas
- Bash compatibility is not yet 100% — test scripts with heavy reliance on arrays, traps, coprocs.
- Startup files: `~/.brushrc` in addition to `~/.bashrc` depending on version.

## ion

**ion**


**Replaces:** `bash` (system shell) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `ion-shell`; also in Redox repos)

### Purpose
Default shell of Redox OS. Faster than Bash, simpler than Nushell, with typed variables and first-class arrays/maps. **One of Mohamed's primary shells.**

### Syntax highlights
```ion
# Strings, arrays, maps
let name = "mohamed"
let files:[str] = [ "a.rs" "b.rs" "c.rs" ]
let config:hmap[str] = hmap[str]::new()

# For loop with array
for f in @files
    echo $f
end

# Conditionals
if test -f Cargo.toml
    cargo build
else
    echo "not a rust project"
end

# Functions
fn greet name:str
    echo "hello $name"
end
greet mohamed
```

### Key commands
| Command | Meaning |
|---------|---------|
| `let VAR = VALUE` | Assign |
| `export VAR = VALUE` | Export to env |
| `fn NAME ARGS; …; end` | Define function |
| `read VAR` | Read from stdin |
| `source FILE` | Source script |
| `alias NAME = CMD` | Alias |

### Examples
1. One-liner: `ion -c "let xs = [1 2 3]; for x in @xs; echo $x; end"`
2. Run a script: `ion ./build.ion`
3. Config: `~/.config/ion/initrc`

### Gotchas
- Syntax is NOT Bash-compatible — rewrite scripts, don't drop Bash ones into Ion directly.
- Arrays expand with `@name`, strings with `$name` — mixing them is a common error.
- Community is smaller than Nushell's; stabilisation work is ongoing.

## nushell

**nushell (nu)**


**Replaces:** `bash`, `zsh` (as interactive + scripting shell) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `nu`; also distro-provided)

### Purpose
Data-oriented, object-pipeline shell. Structured data (tables, records, lists) flows between commands instead of bytestreams. **One of Mohamed's primary shells.**

### Key built-ins
| Command | Meaning |
|---------|---------|
| `ls` | Returns a table of file records |
| `open FILE` | Parse JSON/TOML/YAML/CSV/XML/Parquet into structured data |
| `save FILE` | Write data (format from extension) |
| `where COND` | Filter rows (e.g. `where size > 1MB`) |
| `select COLS` | Project columns |
| `sort-by COL` | Sort |
| `group-by COL` | Group |
| `each { \|x\| … }` | Map closure |
| `reduce --fold INIT { \|it, acc\| … }` | Fold |
| `str FN` | String subcommands |
| `from FMT` / `to FMT` | Convert between formats |
| `http get URL` | HTTP with parsed JSON table output |

### Examples
1. Large files only, sorted: `ls **/* | where type == file and size > 10MB | sort-by size -r`
2. JSON API → table: `http get https://api.github.com/repos/UnbreakableMJ/Understand-Anything | select name stargazers_count`
3. CSV summary: `open data.csv | group-by category | transpose name rows | update rows {|r| $r.rows | length}`
4. Run an external command and parse: `cargo metadata --format-version=1 | from json | get packages | select name version`
5. Pipe to bash only when needed: `ls | get name | to text | bash -c 'xargs wc -l'`

### Gotchas
- Variable syntax is `$var`, not `${var}`; string interpolation uses `$"…"`.
- External commands still return bytestream — wrap with `from json` / `from csv` etc.
- Config: `$nu.config-path` (typically `~/.config/nushell/config.nu`).
- When writing portable scripts for CI, keep Bash as a compatibility layer — Nushell scripts need `nu` installed.

## starship

**starship**


**Replaces:** hand-rolled `PS1`, `oh-my-zsh` prompt themes | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `starship`; also distro-provided)

### Purpose
Minimal, fast, cross-shell prompt. Works in Bash, Zsh, Fish, PowerShell, Nushell, Ion, Elvish, and more.

### Setup
Add to your shell rc:
- Bash: `eval "$(starship init bash)"`
- Zsh: `eval "$(starship init zsh)"`
- Fish: `starship init fish | source`
- Nushell: follow official instructions — Nushell requires a slightly different init path (generate `starship.nu`, source in `config.nu`).
- Ion: write the init script output into `~/.config/ion/initrc`

### Key CLI flags
| Flag | Meaning |
|------|---------|
| `starship init SHELL` | Print init snippet |
| `starship prompt` | Print one-off prompt (for debugging) |
| `starship explain` | Describe active modules |
| `starship module NAME` | Render a single module |
| `starship config` | Open config |
| `starship preset NAME -o FILE` | Dump a preset |

### Config
`$XDG_CONFIG_HOME/starship.toml`:
```toml
format = "$directory$git_branch$git_status$cmd_duration$character"
add_newline = true

[character]
success_symbol = "[➜](green)"
error_symbol = "[✗](red)"

[git_status]
style = "yellow"
```

### Examples
1. Initial setup: `echo 'eval "$(starship init bash)"' >> ~/.bashrc`
2. Use a preset: `starship preset nerd-font-symbols -o ~/.config/starship.toml`
3. Debug what's rendering: `starship explain`

### Gotchas
- Requires a Nerd Font for most presets — or use a text-only preset.
- Per-shell init path varies; always use `starship init SHELL` output verbatim.

## t-rec

**t-rec**


**Replaces:** `asciinema` (for GIF/MP4 output) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `t-rec`)

### Purpose
Terminal recorder that outputs animated GIF or MP4 directly — not just cast files. Records by screenshotting the terminal window.

### Key flags
| Flag | Meaning |
|------|---------|
| `-o FILE` / `--output FILE` | Output (extension picks format) |
| `-m` / `--video` | Produce MP4 (needs ffmpeg) |
| `-d MS` / `--decor MS` | Decoration / border (`shadow`, `none`) |
| `-b` / `--bg` | Background color (`white`, `black`, `transparent`) |
| `-q` / `--quiet` | No intro countdown |
| `-n` / `--natural` | Natural typing speed |
| `-e` / `--end-pause` | Freeze last frame |
| `-s` / `--start-pause` | Freeze first frame |

### Examples
1. Record a session to GIF: `t-rec -o demo.gif`
2. MP4 output: `t-rec -m -o demo.mp4`
3. With pauses at start and end: `t-rec -s 2s -e 2s -o demo.gif`

### Gotchas
- Records a single terminal window — don't resize mid-recording.
- On Wayland needs screencast permissions; X11 works out-of-box.
- MP4 output requires `ffmpeg` on PATH.

## zellij

**zellij**


**Replaces:** `tmux`, `screen` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `zellij`)

### Purpose
User-friendly terminal multiplexer. Layouts, floating panes, plugins (WASM), session manager, discoverable keybindings always visible.

### Key commands
| Command | Meaning |
|---------|---------|
| `zellij` | New or attach default session |
| `zellij -s NAME` | New named session |
| `zellij attach NAME` | Attach |
| `zellij list-sessions` / `ls` | List |
| `zellij kill-session NAME` | Kill |
| `zellij action NAME [ARGS]` | Dispatch action to running session |
| `zellij setup --dump-config > ~/.config/zellij/config.kdl` | Dump config |
| `zellij --layout FILE` | Start with a layout |

### Key bindings

Zellij ships two keybinding presets, selectable in its in-app Configuration
screen (`Ctrl+o` then `c` on Default, `Ctrl+g` then `o` then `c` on Unlock
First). **Check which one is active before assuming a binding** — see Gotchas.

#### Preset 1 — Default (Ctrl prefixes)
| Key | Action |
|-----|--------|
| `Ctrl+p` | Pane mode (`n` new, `d` down-split, `r` right-split, `x` close) |
| `Ctrl+t` | Tab mode (`n` new, `h/l` prev/next, `r` rename) |
| `Ctrl+s` | Scroll / search mode |
| `Ctrl+o` | Session mode (`d` detach, `w` session picker) |
| `Ctrl+g` | Lock (pass keys to underlying program) |
| `Ctrl+q` | Quit |

#### Preset 2 — Unlock First (non-colliding)
Starts locked (`default_mode "locked"`), so every keystroke reaches the program
in the pane and nothing collides with a shell, editor, or TUI. `Ctrl+g` unlocks;
single keys then enter modes; `Ctrl+g` or `esc` locks again.

| Key | Action |
|-----|--------|
| `Ctrl+g` | Unlock (leave locked mode) — the prefix for everything below |
| `Ctrl+g` then `p` | Pane mode (`n` new, `d` down-split, `r` right-split, `x` close) |
| `Ctrl+g` then `t` | Tab mode (`n` new, `h/l` prev/next, `r` rename) |
| `Ctrl+g` then `r` | Resize mode |
| `Ctrl+g` then `s` | Scroll mode (`f` enters search) |
| `Ctrl+g` then `m` | Move mode |
| `Ctrl+g` then `o` | Session mode (`d` detach, `w` session picker, `c` configuration) |
| `Ctrl+g` then `Ctrl+q` | Quit |

### Examples
1. Start a workspace for this project: `zellij -s spacecraft-software`
2. Reattach later: `zellij attach spacecraft-software`
3. Predefined layout: `zellij --layout ~/layouts/dev.kdl`
4. Send a command from outside: `zellij action write-chars "cargo test\n"`

### Gotchas
- **Do not assume the Ctrl-prefix defaults.** Read `~/.config/zellij/config.kdl`
  first: `default_mode "locked"` plus `keybinds clear-defaults=true` means the
  Unlock First preset is active and every mode key needs `Ctrl+g` ahead of it.
- The Default preset's prefix is Ctrl-based (no single prefix key like tmux's
  C-b) — switch preset, or remap in `config.kdl`, if you prefer a tmux feel.
- `zellij setup --dump-config` always emits the **Default** preset, never the
  active one and never Unlock First — it is not a way to read current settings,
  and piping it over a live `config.kdl` silently discards them.
- A config written by a Nix/dotfile generator can be overwritten by zellij at
  runtime (the in-app Configuration screen persists on apply and moves the old
  file to `config.kdl.bak.N`), and overwritten right back on the next
  generator run. Change the generator's source, not the live file.
- Validate a config without loading it: `ZELLIJ_CONFIG_FILE=<path> zellij setup
  --check` (expect `[CONFIG FILE]: Well defined.`).
- Copy/paste across panes relies on OSC52 — enable in your terminal.
- Plugin system loads WASM modules from `$XDG_DATA_HOME/zellij/plugins/`.

## zoxide

**zoxide (z)**


**Replaces:** `cd` + shell history navigation | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `zoxide` — needs shell init; prefer `programs.zoxide.enable`, see local-execution.md)

### Purpose
Smart directory jumper. Ranks visited directories by frequency+recency ("frecency"). Bound to `z` (or any alias you pick).

### Shell init (required)
Add one of these to your rc:
- Bash: `eval "$(zoxide init bash)"`
- Zsh: `eval "$(zoxide init zsh)"`
- Fish: `zoxide init fish | source`
- **Nushell**: add `zoxide init nushell | save -f ~/.zoxide.nu` then `source ~/.zoxide.nu`
- **Ion**: `zoxide init ion` output into your `~/.config/ion/initrc`

### Key commands
| Command | Meaning |
|---------|---------|
| `z PATTERN` | Jump to best match |
| `z foo bar` | Jump to best dir matching both |
| `zi PATTERN` | Interactive selection (requires `fzf`) |
| `z -` | Previous directory (like `cd -`) |
| `zoxide add PATH` | Manually add |
| `zoxide remove PATH` | Remove from DB |
| `zoxide query PATTERN` | Print match without cd'ing |
| `zoxide edit` | Edit DB in `$EDITOR` |

### Examples
1. Jump to the last-used project directory matching `spacecraft-software`: `z spacecraft-software`
2. Match on two tokens: `z bravais src`
3. Pick interactively: `zi`
4. Preview match without jumping: `zoxide query -l bravais`

### Gotchas
- You must `cd` into directories first for zoxide to learn them.
- Conflicts with bash's builtin `z`/aliases — check `type z`.
- DB lives at `$_ZO_DATA_DIR` (defaults under `$XDG_DATA_HOME`).
