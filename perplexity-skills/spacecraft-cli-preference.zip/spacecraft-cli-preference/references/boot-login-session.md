# Boot, Login & Session

## cosmic-session

**cosmic-session**


**Replaces:** `gnome-session`, `plasma-session` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (distro-provided)

### Purpose
Session manager for COSMIC DE. Launched by your display manager when COSMIC is selected.

### Usage
Typically invoked as `cosmic-session` from a `.desktop` session file:
```
/usr/share/wayland-sessions/cosmic.desktop
```

### Commands
| Command | Meaning |
|---------|---------|
| `cosmic-session` | Start session (usually called by DM) |
| `systemctl --user status cosmic-session.target` | Session status |

### Gotchas
- Not meant to be invoked manually from a running session — restart via DM.
- Logs in `journalctl --user -u cosmic-session.target`.

## greetd

**greetd**


**Replaces:** `getty` + `agetty`, LightDM/SDDM (minimal alternative) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (distro package: `greetd`)

### Purpose
Minimal, generic login daemon that delegates the UI to a separate greeter (e.g. `tuigreet`, `gtkgreet`, `regreet`).

### Config
`/etc/greetd/config.toml`:
```toml
[terminal]
vt = 1

[default_session]
command = "tuigreet --cmd niri-session"
user = "greeter"
```

### Key commands
| Command | Meaning |
|---------|---------|
| `systemctl enable --now greetd` | Enable service |
| `journalctl -u greetd` | Logs |

### Examples
1. Enable on NixOS (Bravais): `services.greetd.enable = true;` + greeter settings.
2. Switch greeter: edit `default_session.command`, then restart service.
3. Debug session-start issues: `journalctl -u greetd -b`.

### Gotchas
- Mis-configured `command =` leaves you stuck at VT1 with no login — always keep another TTY open.
- The greeter user must exist (distro packages create it; NixOS handles it via the module).

## lanzaboote

**lanzaboote**


**Replaces:** `sbctl`, systemd-boot without signing | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (NixOS flake module)

### Purpose
UEFI Secure Boot for NixOS. Builds and signs bootloader + kernel images with your own Secure Boot keys. Used in Bravais.

### Key commands
| Command | Meaning |
|---------|---------|
| `lzbt-systemd generate-keys PATH` | Generate PK/KEK/db keys |
| `lzbt-systemd enroll-keys PATH` | Enroll into UEFI firmware |
| `lzbt-systemd install PATH /boot` | Install signed bootloader |
| `lzbt-systemd status` | Show SB status |

### Typical NixOS flake wiring
```nix
imports = [ lanzaboote.nixosModules.lanzaboote ];
boot.loader.systemd-boot.enable = lib.mkForce false;
boot.lanzaboote = {
  enable = true;
  pkiBundle = "/etc/secureboot";
};
```

### Examples
1. Generate keys: `sudo lzbt-systemd generate-keys /etc/secureboot`
2. Enroll (after firmware set to Setup Mode): `sudo lzbt-systemd enroll-keys /etc/secureboot`
3. Check status: `bootctl status`

### Gotchas
- Back up firmware keys before enrolling your own — some firmwares can't easily restore factory PK.
- Microsoft KEK/db can be preserved via `--include-microsoft` during enrollment (needed for dual-boot).
- NixOS rebuild after enabling lanzaboote replaces systemd-boot; test with a rescue USB on hand.

## lemurs

**lemurs**


**Replaces:** LightDM, SDDM (TUI alternative) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (distro-provided; upstream crate: `lemurs`)

### Purpose
Customisable TUI display manager. Simpler than `greetd`+`tuigreet` split — lemurs ships as a complete standalone DM.

### Config
`/etc/lemurs/config.toml`. Declare sessions under `[[environments]]`.

### Key commands
| Command | Meaning |
|---------|---------|
| `systemctl enable --now lemurs` | Enable service |
| `lemurs --preview` | Preview UI without logging in |

### Examples
1. Preview theme: `lemurs --preview`
2. Enable: standard systemd service enablement as above.
3. Add a session: append to `/etc/lemurs/wayland/` or config.

### Gotchas
- Less widely packaged than `greetd` — check distro availability.
- Keep config under VCS; misconfigured sessions lock you out like any DM.

## tuigreet

**tuigreet**


**Replaces:** graphical display managers (minimal use case) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (distro package: `tuigreet` / `greetd-tuigreet`)

### Purpose
Console-based greeter for `greetd`. Ideal companion to Niri, LeftWM, sway, river.

### Key flags
| Flag | Meaning |
|------|---------|
| `-c CMD` / `--cmd CMD` | Command to launch on login |
| `-s SEC` / `--window-padding N` | Padding |
| `-t` / `--time` | Show clock |
| `-r` / `--remember` | Remember last user |
| `--remember-session` | Remember last session choice |
| `--asterisks` | Hide password as asterisks |
| `--asterisks-char C` | Asterisk char |
| `--theme THEME` | Named theme |
| `--greeting TEXT` | Custom greeting |
| `--sessions PATH` | Extra `.desktop` session dir |
| `--xsessions PATH` / `--wlsessions PATH` | Per-protocol session dirs |

### Examples
1. Niri session with memory: `tuigreet -r --remember-session -c niri-session`
2. With custom greeting and clock: `tuigreet -t --greeting "Welcome to Spacecraft Software" -c /usr/bin/niri-session`
3. Multiple sessions: `tuigreet --wlsessions /usr/share/wayland-sessions --xsessions /usr/share/xsessions`

### Gotchas
- Runs as the `greeter` user — ensure it has permission to read `.desktop` files.
- Session picker appears only if multiple `.desktop` session files are present.

## xdpc

**xdg-desktop-portal-cosmic**


**Replaces:** other XDG portal backends (on COSMIC) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (distro package: `xdg-desktop-portal-cosmic`)

### Purpose
Wayland XDG portal backend for the COSMIC desktop. Provides screenshot, screencast, file-chooser, and settings interfaces for sandboxed apps (Flatpak, browsers).

### Usage
Started automatically by `xdg-desktop-portal` when the COSMIC session is active. No user-facing CLI beyond:

| Command | Meaning |
|---------|---------|
| `systemctl --user status xdg-desktop-portal` | Service status |
| `systemctl --user restart xdg-desktop-portal-cosmic` | Restart backend |

### Gotchas
- Running multiple backends (`-gtk`, `-gnome`, `-cosmic`) simultaneously causes portal confusion — prefer the one matching your DE.
- Screencast uses `pipewire` — ensure it's running.

## xremap

**xremap**


**Replaces:** `xmodmap`, `setxkbmap` (partial), `kmonad` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `xremap` — build with the matching feature (`gnome`, `wlroots`, `x11`, `kde`, `hypr`))

### Purpose
Dynamic key remapper for Linux. Supports X11 and Wayland compositors. Config in YAML with layers, app-specific bindings, macros.

### Example config (`~/.config/xremap/config.yml`)
```yaml
modmap:
  - name: CapsLock to Ctrl
    remap:
      CAPSLOCK: LEFTCTRL
keymap:
  - name: Emacs-like bindings in terminals
    application:
      only: [Alacritty, foot, kitty]
    remap:
      C-n: Down
      C-p: Up
```

### Key flags
| Flag | Meaning |
|------|---------|
| `--config FILE` | Config path |
| `--watch` | Reload on change |
| `--device /dev/input/…` | Specific device |
| `--completions SHELL` | Shell completions |

### Examples
1. Run with systemd user service: `systemctl --user enable --now xremap`
2. Ad-hoc: `sudo xremap ~/.config/xremap/config.yml`
3. Auto-reload on config changes: `xremap --watch ~/.config/xremap/config.yml`

### Gotchas
- Needs access to `/dev/input/event*` — root or `input` group + `uinput` module.
- Wayland compositors need their feature flag (`--features KDE|gnome|wlroots|hypr|x11`) at build time.
- App-specific rules rely on compositor extensions that vary by DE.
