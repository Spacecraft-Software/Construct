# Network Configuration

## adguardvpn-cli

**AdGuard VPN CLI**


**Replaces:** manual VPN dial-up | **Language:** 🐹 Go | **Install:** via `spacecraft-missing-pkg` (upstream installer (AdGuard official))

### Purpose
Command-line client for AdGuard VPN. Manage connection, protocols, DNS, split-tunnel.

### Key commands
| Command | Meaning |
|---------|---------|
| `adguardvpn-cli login` | Authenticate |
| `adguardvpn-cli connect` | Connect (interactive location picker) |
| `adguardvpn-cli connect -l LOC` | Connect to location |
| `adguardvpn-cli disconnect` | Disconnect |
| `adguardvpn-cli status` | Status |
| `adguardvpn-cli list-locations` | Available servers |
| `adguardvpn-cli config set-mode` | `tun` / `socks` |
| `adguardvpn-cli site-exclusions` | Split-tunnel list |

### Examples
1. Login and connect to a specific server: `adguardvpn-cli login && adguardvpn-cli connect -l gb-london`
2. Check status: `adguardvpn-cli status`
3. Systemd-managed: create a unit that runs `adguardvpn-cli connect -l fastest`

### Gotchas
- `tun` mode needs root/capability; `socks` mode is per-app.
- Login stores credentials in plaintext config on older versions — check file permissions.

## impala

**impala**


**Replaces:** `iwctl` (interactive), `nmtui` for Wi-Fi | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `impala`)

### Purpose
TUI front-end for `iwd`. Scan, connect, manage known networks without memorising `iwctl` subcommands.

### Launch
```
impala
```

### Key bindings
| Key | Action |
|-----|--------|
| `s` | Scan |
| `Enter` | Connect to highlighted SSID |
| `d` | Disconnect |
| `k` | Manage known networks |
| `t` | Toggle power |
| `?` | Help |
| `q` | Quit |

### Gotchas
- Requires `iwd` running (`systemctl enable --now iwd`).
- Coexists badly with NetworkManager on Wi-Fi — pick one.

## iwd

**iwd / iwctl**


**Replaces:** `wpa_supplicant` | **Language:** ⚠️ C (Intel) | **Install:** via `spacecraft-missing-pkg` (distro package: `iwd`)

### Purpose
Modern Wi-Fi daemon by Intel, smaller and faster than wpa_supplicant. `iwctl` is its interactive CLI.

### Key commands
| Command | Meaning |
|---------|---------|
| `iwctl device list` | List wireless devices |
| `iwctl station DEV scan` | Scan |
| `iwctl station DEV get-networks` | Show SSIDs |
| `iwctl station DEV connect SSID` | Connect |
| `iwctl known-networks list` | Saved networks |
| `iwctl known-networks SSID forget` | Forget |
| `iwctl station DEV disconnect` | Disconnect |
| `iwctl --passphrase PW station DEV connect SSID` | Non-interactive |

### Examples
1. Scan + connect interactively: `iwctl` then `station wlan0 scan` → `station wlan0 connect MyWifi`
2. Scripted connect: `iwctl --passphrase "$PW" station wlan0 connect "$SSID"`
3. Forget a network: `iwctl known-networks "$SSID" forget`

### Gotchas
- Disable wpa_supplicant / NetworkManager Wi-Fi backend to avoid conflicts.
- Config in `/var/lib/iwd/<SSID>.psk`; secure permissions automatically.

## nmstate

**nmstate**


**Replaces:** `nmcli`, `ip`, raw NetworkManager config | **Language:** 🦀 Rust (core lib) | **Install:** via `spacecraft-missing-pkg` (distro package: `nmstate`)

### Purpose
Declarative network state management. Describe desired state in YAML/JSON, apply idempotently. Integrates with NetworkManager.

### Key commands
| Command | Meaning |
|---------|---------|
| `nmstatectl show` | Dump current state (YAML) |
| `nmstatectl show IFACE` | Single interface |
| `nmstatectl apply FILE` | Apply desired state |
| `nmstatectl set FILE` | Partial apply |
| `nmstatectl rollback` | Undo last change |
| `nmstatectl commit` | Make last change permanent |
| `nmstatectl edit IFACE` | Edit state in `$EDITOR` |
| `nmstatectl gc` | Garbage-collect checkpoints |

### Example state file
```yaml
interfaces:
  - name: eth0
    type: ethernet
    state: up
    ipv4:
      enabled: true
      dhcp: true
    ipv6:
      enabled: true
      autoconf: true
```

### Examples
1. Snapshot current config: `nmstatectl show > net.yaml`
2. Apply a config: `nmstatectl apply net.yaml`
3. Safely try + auto-rollback after 30s: `nmstatectl apply --timeout 30 net.yaml && nmstatectl commit`

### Gotchas
- Checkpoints auto-rollback if not committed within timeout — intentional safety mechanism.
- Operates on the managed interfaces of NetworkManager; wired Wi-Fi management still goes through NM.
