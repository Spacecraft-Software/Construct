# Package Managers

## am

**am (AppMan)**


**Replaces:** manual AppImage management | **Language:** ⚠️ Bash | **Install:** via `spacecraft-missing-pkg` (upstream install script)

### Purpose
Bash-based AppImage manager. Lightweight, no daemon, extensive catalog. Secondary choice after `zap`.

### Key commands
| Command | Meaning |
|---------|---------|
| `am -i PKG` | Install |
| `am -u` | Update all |
| `am -r PKG` | Remove |
| `am -q QUERY` | Search |
| `am -l` | List installed |
| `am -a` / `--about PKG` | About |

### Examples
1. Install: `am -i librewolf`
2. Update everything: `am -u`

### Gotchas
- Bash-only — edit scripts in `$AM_INSTALLDIR` to debug.
- AppImages install under `~/.local/bin` by default.

## brew

**brew**


**Replaces:** — (cross-platform fallback) | **Language:** ⚠️ Ruby | **Install:** via `spacecraft-missing-pkg` (upstream: <https://brew.sh>)

### Purpose
Homebrew: macOS and Linux package manager. Cross-platform fallback when a tool isn't in your distro's repos.

### Key commands
| Command | Meaning |
|---------|---------|
| `brew update` | Refresh tap metadata |
| `brew upgrade [PKG]` | Upgrade all / one |
| `brew install PKG` | Install |
| `brew uninstall PKG` | Remove |
| `brew search QUERY` | Search |
| `brew info PKG` | Details |
| `brew list` | Installed |
| `brew doctor` | Diagnose install |
| `brew bundle dump` | Export installed set |
| `brew bundle` | Install from Brewfile |

### Examples
1. Install multiple: `brew install eza bat fd ripgrep jaq`
2. Export current setup: `brew bundle dump --file ~/Brewfile`
3. Reinstall on a new machine: `brew bundle --file ~/Brewfile`

### Gotchas
- On Linux, paths live under `/home/linuxbrew/.linuxbrew` by default.
- Casks (`brew install --cask`) only work on macOS.

## dotter

**dotter**


**Replaces:** `stow`, `chezmoi`, `yadm` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `dotter`)

### Purpose
Dotfile manager with templating (Handlebars), per-package toggling, and symlink/copy deployment.

### Project layout
```
dotfiles/
├── .dotter/
│   ├── global.toml
│   └── local.toml
├── nushell/
│   └── config.nu
└── starship/
    └── starship.toml
```

### Key commands
| Command | Meaning |
|---------|---------|
| `dotter deploy` | Apply configs |
| `dotter undeploy` | Remove deployed files |
| `dotter init` | Initialise `.dotter/` |
| `dotter -p` / `--patch` | Generate diffs instead of applying |
| `dotter -d` / `--dry-run` | Dry run |
| `-c FILE` / `--config FILE` | Alt config file |
| `-f` / `--force` | Overwrite existing |

### Examples
1. Deploy current host's configs: `dotter deploy`
2. Preview: `dotter -d deploy`
3. Templated config with variables: define in `.dotter/local.toml`, use `{{ .variable }}` in source files

### Gotchas
- Lives well with git — commit `.dotter/global.toml` but keep `local.toml` per-host.
- First deploy aborts if target exists; use `-f` only after reviewing.

## flatpak

**flatpak**


**Replaces:** native packages for sandboxed GUI apps | **Language:** ⚠️ C | **Install:** via `spacecraft-missing-pkg` (distro package: `flatpak`)

### Purpose
Sandboxed universal app packaging with per-app permissions.

### Key commands
| Command | Meaning |
|---------|---------|
| `flatpak remote-add --if-not-exists flathub URL` | Add Flathub repo |
| `flatpak search QUERY` | Search |
| `flatpak install FLATREF` | Install |
| `flatpak run APP_ID` | Launch |
| `flatpak list` | Installed |
| `flatpak update` | Update all |
| `flatpak uninstall APP_ID` | Remove |
| `flatpak override --user APP_ID FLAG` | Permission tweaks |
| `flatpak info APP_ID` | Details |

### Examples
1. Add Flathub: `flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo`
2. Install: `flatpak install flathub org.signal.Signal`
3. Run: `flatpak run org.signal.Signal`
4. Restrict filesystem access: `flatpak override --user --nofilesystem=home org.signal.Signal`

### Gotchas
- Runtime + app separation means large initial downloads; subsequent installs share runtimes.
- Permissions default-permissive on some apps; audit with `flatpak info --show-permissions`.

## guix

**guix**


**Replaces:** — (alternative declarative PM) | **Language:** (λ) Guile Scheme | **Install:** via `spacecraft-missing-pkg` (upstream: <https://guix.gnu.org/>)

### Purpose
Functional/declarative package manager and (optional) distro. Transactional upgrades, rollbacks, per-user profiles. Alternative to Nix with a Scheme-based language.

### Key commands
| Command | Meaning |
|---------|---------|
| `guix install PKG` | User install |
| `guix remove PKG` | Uninstall |
| `guix upgrade` | Upgrade all |
| `guix search QUERY` | Search |
| `guix show PKG` | Info |
| `guix pull` | Update Guix itself |
| `guix shell PKG…` | Ephemeral shell |
| `guix environment --container` | Isolated env |
| `guix package --roll-back` | Revert last profile change |
| `guix system reconfigure FILE` | Apply system config (Guix System) |

### Examples
1. Ephemeral dev shell: `guix shell rust cargo`
2. Roll back a bad upgrade: `guix package --roll-back`
3. Update Guix itself: `guix pull && guix upgrade`

### Gotchas
- Manifests are Scheme expressions — syntax is stricter than Nix's.
- Free-software-only by policy; proprietary drivers need the `nonguix` channel.

## linutil

**linutil**


**Replaces:** ad-hoc post-install scripts | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `linutil-tui`; or upstream installer)

### Purpose
Distro-agnostic TUI for Linux setup and maintenance: system updates, driver installs, common toolchain setup, tweaks. Community scripts bundled.

### Launch
```
linutil          # TUI
linutil --help   # flags
```

### Key bindings
| Key | Action |
|-----|--------|
| `↑`/`↓` | Navigate |
| `Enter` | Run selected script |
| `/` | Search |
| `Tab` | Toggle tree sections |
| `q` | Quit |

### Gotchas
- Scripts are opinionated community contributions — read before executing.
- Some scripts assume Arch; check compatibility in each section header.

## nix

**nix**


**Replaces:** — (Spacecraft Software-sanctioned for Bravais) | **Language:** ⚠️ C++ | **Install:** via `spacecraft-missing-pkg` (upstream: <https://nixos.org/download>)

### Purpose
Functional/declarative package manager and build system. Reproducible dev shells, system configs (NixOS), per-project environments.

### Key commands (flakes-first)
| Command | Meaning |
|---------|---------|
| `nix run NIXPKG` | Run a package without installing |
| `nix shell NIXPKG…` | Ephemeral shell with those packages |
| `nix develop [.#NAME]` | Enter dev shell defined in `flake.nix` |
| `nix build [.#PKG]` | Build and symlink `result/` |
| `nix flake init` | Scaffold a flake |
| `nix flake update` | Update lock |
| `nix flake check` | Evaluate all outputs |
| `nix profile install NIXPKG` | User-profile install — **prohibited on a declaratively managed host** (see below) |
| `nix profile list` / `remove` | Manage profile |
| `nixos-rebuild switch` | Apply system config (NixOS) |
| `home-manager switch` | Apply user config (Home Manager) |

### Examples
1. Run ripgrep without installing: `nix run nixpkgs#ripgrep -- "TODO" src/`
2. Temporary dev shell: `nix shell nixpkgs#rustc nixpkgs#cargo`
3. Per-project shell (with `flake.nix`): `nix develop`
4. Build a derivation: `nix build .#ferrocast-cli`

### Gotchas
- Enable flakes once: in `nix.conf` set `experimental-features = nix-command flakes`.
- `channels` are the legacy model; prefer flakes for new projects (per Bravais).
- Store paths live under `/nix/store`; never touch directly.
- **Never `nix profile install` or `nix-env -i` on a declaratively managed
  host.** They write a durable profile entry the host's configuration cannot
  see, and it survives the next rebuild as drift. For an ephemeral need use
  `nix run` / `nix shell`; for a persistent one propose an
  `environment.systemPackages` / `home.packages` edit. See
  `spacecraft-missing-pkg`.

## omni

**omni**


**Replaces:** per-distro package managers (bridge) | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `omnicli`; or GitHub release)

### Purpose
Universal package-manager front-end. Translates generic install/search/remove commands to the host's native PM (pacman, apt, dnf, brew, xbps, nix, flatpak, pkg, …).

### Key commands
| Command | Meaning |
|---------|---------|
| `omni install PKG` | Install via native PM |
| `omni remove PKG` | Uninstall |
| `omni search QUERY` | Search |
| `omni update` | Refresh package indexes |
| `omni upgrade` | Upgrade all |
| `omni info PKG` | Show package info |
| `omni list` | Installed packages |

### Examples
1. Cross-distro install line in docs: `omni install ripgrep fd eza bat`
2. Full system upgrade: `omni upgrade`
3. Script-friendly search: `omni search --json rust`

### Gotchas
- Routes to whichever PM is detected first — force backend with `--backend pacman|apt|nix|…`.
- Not every distro ships omni; bootstrapping still uses the native PM.

## paru

**paru**


**Replaces:** `yay`, raw `makepkg` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (Arch package: `paru`)

> **Arch-only, and installs are consent-gated.** On any non-Arch host this row
> does not apply; on a declaratively managed host it installs outside the
> configuration and drifts it. Read-only queries (`paru -Qs`, `paru -Si`) are
> fine; anything that installs or upgrades goes through
> `spacecraft-missing-pkg` and needs the user's go-ahead — it also needs root,
> so it is a hand-off. See [local-execution.md](local-execution.md).

### Purpose
Feature-rich AUR helper for Arch and derivatives. `pacman`-compatible flags, with AUR search, PKGBUILD inspection, and upgrade workflows.

### Key commands
| Command | Meaning |
|---------|---------|
| `paru` | Interactive upgrade (repo + AUR) |
| `paru -S PKG` | Install (repo or AUR) |
| `paru -Ss QUERY` | Search repo |
| `paru -Sua` | Upgrade AUR packages only |
| `paru -Syu` | Full upgrade |
| `paru -Rns PKG` | Remove with deps + config |
| `paru -Qu` | Pending upgrades |
| `paru -G PKG` | Clone PKGBUILD |
| `paru -Fy` / `paru -F FILE` | File database (find which pkg owns FILE) |

### Examples
1. Interactive review + upgrade: `paru`
2. Install from AUR: `paru -S rage`
3. Dry-run of upgrades: `paru -Qu`
4. Only AUR upgrades: `paru -Sua`

### Gotchas
- AUR PKGBUILDs run arbitrary build scripts — always review (`paru --review`).
- Keep `paru.conf` `SudoLoop` on for unattended long builds.

## topgrade

**topgrade**


**Replaces:** hand-written "update everything" scripts | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (upstream crate: `topgrade`)

> **Never run unprompted — hand off.** A single invocation updates the entire
> system across every manager it finds; that is the user's decision, not the
> agent's. **On a declaratively managed host (NixOS, Home Manager, Guix) it is
> the wrong tool entirely** — it installs around the configuration and drifts
> it. See [local-execution.md](local-execution.md).

### Purpose
Detects every package manager/tool on the system (apt, pacman, nix, flatpak, brew, cargo, rustup, npm, pnpm, pip, gem, tldr, vim plugins, docker, …) and updates them all in one pass.

### Key flags
| Flag | Meaning |
|------|---------|
| `-y` / `--yes` | No confirmations |
| `--only STEP[,STEP]` | Run only listed steps |
| `--disable STEP` | Skip step |
| `--dry-run` / `-n` | Show what would run |
| `-c` / `--cleanup` | Do cleanup passes (cargo cache, apt autoremove, etc.) |
| `--no-retry` | Don't prompt to retry failed steps |
| `--skip-notify` | No notifications |
| `-t SECS` / `--ssh-arguments` | Remote targets |
| `--edit-config` | Open config |

### Examples
1. Update everything: `topgrade`
2. Dry-run: `topgrade -n`
3. Only rust + cargo: `topgrade --only rustup,cargo`
4. Systemd timer friendly: `topgrade -y -c --skip-notify`

### Gotchas
- Runs many privileged commands in sequence (`sudo pacman`, etc.) — expect password prompts, or set up `sudo` caching.
- Config: `$XDG_CONFIG_HOME/topgrade.toml` — disable noisy steps there.

## zap

**zap**


**Replaces:** `appimaged`, `am` | **Language:** 🦀 Rust | **Install:** via `spacecraft-missing-pkg` (GitHub release)

### Purpose
High-performance AppImage manager: install, update, integrate (desktop entries + icons), remove.

### Key commands
| Command | Meaning |
|---------|---------|
| `zap install NAME` | Install an AppImage from GitHub/custom URL |
| `zap list` | List installed |
| `zap update` | Check/update all |
| `zap remove NAME` | Remove |
| `zap search QUERY` | Search catalog |
| `zap daemon` | Background update service |

### Examples
1. Install an AppImage by name: `zap install appimagelauncher`
2. Install from a direct URL: `zap install --from https://example.com/app.AppImage my-app`
3. Update all: `zap update`
4. Uninstall: `zap remove my-app`

### Gotchas
- AppImage integration requires XDG directories under `~/.local/share/applications/`.
- No sandboxing by default — treat AppImages as equivalent-trust to distro packages.
