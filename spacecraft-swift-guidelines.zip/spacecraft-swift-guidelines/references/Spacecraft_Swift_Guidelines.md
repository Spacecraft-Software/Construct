# Spacecraft Swift Guidelines — Full Reference

**Version:** 1.0
**Date:** 2026-07-12
**Author:** Mohamed Hammad & Spacecraft Software
**Compatibility:** Model-agnostic — the current Claude 5 family (Opus, Fable, Sonnet), Grok, and any comparably capable reasoning model

This document expands on the `SKILL.md` for Swift 6.2+ systems programming. It provides complete, compile-checked configurations and skeletons for background execution offloading, SwiftUI ViewModel isolation, Swift Testing with zipped arguments, and optional safety checks.

---

## 1. Swift 6.2 `@concurrent` Background Execution (SE-0461)

Swift 6.2 defaults to staying on the caller's actor for nonisolated async functions. To run computations in the background, explicitly annotate functions with `@concurrent` to hop to the cooperative concurrent pool.

```swift
import Foundation

public struct TelemetryPacket: Sendable, Codable {
    public let id: UUID
    public let value: Double
    public let timestamp: Date
}

/// A service to process telemetry.
public actor TelemetryProcessor {
    private var processedPackets: [TelemetryPacket] = []

    public init() {}

    /// Main entry point isolated to actor.
    public func processPackets(_ rawData: [Data]) async throws {
        // Explicitly offload data parsing to a background concurrent task.
        let parsed = try await parseTelemetryConcurrent(rawData)
        self.processedPackets.append(contentsOf: parsed)
    }

    /// Explicitly offloaded background parsing function.
    /// Runs on the global concurrent threadpool via the @concurrent pragma.
    @concurrent
    private func parseTelemetryConcurrent(_ data: [Data]) async throws -> [TelemetryPacket] {
        try await withThrowingTaskGroup(of: TelemetryPacket.self) { group in
            for rawBytes in data {
                group.addTask {
                    // Check task cancellation before parsing
                    try Task.checkCancellation()
                    let decoder = JSONDecoder()
                    decoder.dateDecodingStrategy = .iso8601
                    return try decoder.decode(TelemetryPacket.self, from: rawBytes)
                }
            }

            var results: [TelemetryPacket] = []
            for try await packet in group {
                results.append(packet)
            }
            return results
        }
    }
}
```

---

## 2. MainActor ViewModel & SwiftUI Isolation

Isolate SwiftUI state updates to the `@MainActor`. Offload heavy I/O tasks to background contexts to prevent UI thread starvation.

```swift
import SwiftUI

@MainActor
public final class TelemetryViewModel: ObservableObject {
    @Published public private(set) var packets: [TelemetryPacket] = []
    @Published public private(set) var isLoading = false
    @Published public var errorMessage: String?

    private let processor = TelemetryProcessor()

    public init() {}

    public func loadPackets(from urls: [URL]) async {
        self.isLoading = true
        self.errorMessage = nil
        
        defer { self.isLoading = false }

        do {
            var rawData: [Data] = []
            // Network fetching is non-blocking async
            for url in urls {
                let (data, _) = try await URLSession.shared.data(from: url)
                rawData.append(data)
            }

            // Processing occurs on background actor, then hops back to MainActor
            try await processor.processPackets(rawData)
        } catch {
            self.errorMessage = error.localizedDescription
        }
    }
}

struct TelemetryView: View {
    @StateObject private var viewModel = TelemetryViewModel()

    var body: some View {
        NavigationStack {
            List(viewModel.packets, id: \.id) { packet in
                HStack {
                    Text(packet.id.uuidString.prefix(8))
                    Spacer()
                    Text(String(format: "%.2f", packet.value))
                }
            }
            .navigationTitle("Telemetry Log")
            .overlay {
                if viewModel.isLoading {
                    ProgressView()
                }
            }
            .task {
                let mockURLs = [URL(string: "https://api.spacecraft.org/t1")!]
                await viewModel.loadPackets(from: mockURLs)
            }
        }
    }
}
```

---

## 3. Zipped Parameterized Swift Testing (SE-0470)

Use the Swift Testing framework for testing. Parameterize tests using `arguments` tuples. Use `zip()` to align inputs rather than performing combinations.

```swift
// Tests/TelemetryTests.swift
import Testing
import Foundation
@testable import TelemetryService

@Suite("Telemetry Service Tests")
struct TelemetryTests {
    
    // Zipped parameterized test case
    @Test("Validate Parsing Outputs", arguments: zip(
        [
            "{\"id\":\"00000000-0000-0000-0000-000000000000\",\"value\":42.5,\"timestamp\":\"2026-07-12T20:00:00Z\"}",
            "{\"id\":\"11111111-1111-1111-1111-111111111111\",\"value\":-10.0,\"timestamp\":\"2026-07-12T21:00:00Z\"}"
        ],
        [42.5, -10.0]
    ))
    func testParsing(jsonString: String, expectedValue: Double) throws {
        guard let data = jsonString.data(using: .utf8) else {
            Issue.record("Failed to convert mock json to UTF8 data")
            return
        }

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        
        let packet = try decoder.decode(TelemetryPacket.self, from: data)
        
        #expect(packet.value == expectedValue)
        #expect(packet.timestamp != nil)
    }

    @Test("Assert invalid JSON throws error")
    func testParsingFailure() {
        let invalidData = "invalid-json-data".data(using: .utf8)!
        let decoder = JSONDecoder()
        
        #expect(throws: DecodingError.self) {
            try decoder.decode(TelemetryPacket.self, from: invalidData)
        }
    }
}
```

---

## 4. Retain Cycles & ARC Memory Hygiene

To prevent leaks in async closures, use weak capturing. Avoid force-unwraps (`!`) to prevent runtime crashes.

```swift
import Foundation

public final class DeviceMonitor {
    private var updateHandler: ((Double) -> Void)?
    private var lastValue: Double = 0.0

    public init() {}

    public func configureHandler() {
        // Use weak self to prevent retain cycles
        self.updateHandler = { [weak self] val in
            guard let self = self else { return }
            self.lastValue = val
            print("Received value: \(val)")
        }
    }

    public func processSample(value: Double?) {
        // Safe unwrapping instead of force-unwrapping (value!)
        guard let unwrappedValue = value else {
            print("Received null telemetry reading")
            return
        }
        self.updateHandler?(unwrappedValue)
    }
}
```

---

## 5. Swift Package Manager Configuration (`Package.swift`)

Configure strict concurrency checking and warnings as errors in `Package.swift`.

```swift
// swift-tools-version: 6.2
import PackageDescription

let package = Package(
    name: "TelemetryService",
    platforms: [
        .iOS(.v17),
        .macOS(.v14)
    ],
    products: [
        .library(name: "TelemetryService", targets: ["TelemetryService"])
    ],
    dependencies: [],
    targets: [
        .target(
            name: "TelemetryService",
            dependencies: [],
            swiftSettings: [
                // Enforce strict concurrency checks (warnings treated as errors in Swift 6)
                .enableUpcomingFeature("StrictConcurrency"),
                .enableUpcomingFeature("NonisolatedNonsendingByDefault"),
                .enableUpcomingFeature("InferIsolatedConformances"),
                .unsafeFlags(["-warnings-as-errors"])
            ]
        ),
        .testTarget(
            name: "TelemetryServiceTests",
            dependencies: ["TelemetryService"],
            swiftSettings: [
                .enableUpcomingFeature("StrictConcurrency"),
                .unsafeFlags(["-warnings-as-errors"])
            ]
        )
    ]
)
```

---

## 6. Common Pitfalls & Troubleshooting

| Pitfall | Symptom | Corrective Action |
| :--- | :--- | :--- |
| **Force-unwrapping (`!`) optionals** | Thread crashes with fatal error | Use `guard let` or provide defaults using `??`. |
| **Retain cycles in async closures** | Memory leaks (objects are never released) | Capture references weakly: `[weak self]`. |
| **MainActor blockages** | SwiftUI interfaces freeze or frame drops | Annotate heavy functions with `@concurrent` or process on a separate background `actor`. |
| **Unchecked Sendable escapes** | Undefined thread data races | Avoid `@unchecked Sendable`. Use locks only if wrapping FFI structures, verified under Thread Sanitizer. |
| **Cartesian parameterized tests** | Tests run too many combinations | Use `zip()` inside `@Test(arguments: zip(...))` to align arguments. |

---

## 7. Code Review Compliance Gate

Before merging Swift code, verify:
1. Compilation passes with strict concurrency checks and `-warnings-as-errors` active.
2. No force-unwraps (`!`) or force-casts (`as!`) exist in any production path.
3. Every asynchronous closure capturing `self` uses the `[weak self]` capture list.
4. ViewModels update state variables on the `@MainActor`.
5. Unit tests run on the modern `Testing` framework (not `XCTest`).

---

## 8. SwiftUI State Ownership & View Composition

Ensure every view uses the correct property wrapper based on ownership, and keep data flow unidirectional: data flows down, events flow up.

### Property Wrapper Decision Tree
1. **Ephemeral Local Value Type:** View owns the state and it should reset when the view is destroyed -> Use `@State`.
2. **Parent-Owned Value Type:** Parent view owns the state and this view only reads and writes to it -> Use `@Binding`.
3. **Reference-Type Model (iOS 17+):** Model has complex business logic/derived state -> Use `@Observable` macro on the class, and reference it directly in the view.
4. **Reference-Type Model (Legacy / Backwards Compatibility):** Model supports iOS 16- -> Use `@StateObject` in the owner view, and `@ObservedObject` in child views.
5. **Shared App-Wide/Feature-Wide State:** State is shared across many child views in the hierarchy -> Inject via `@Environment` (for `@Observable` models) or `@EnvironmentObject` (for legacy `ObservableObject`).

### Skeleton: Parent-Child Unidirectional Data Flow
```swift
import SwiftUI

// 1. Immutable Data Model
public struct TaskItem: Identifiable, Sendable, Hashable {
    public let id: UUID
    public let title: String
    public let isCompleted: Bool
}

// 2. Main ViewModel (MainActor isolated state owner)
@MainActor
@Observable
public final class TaskListViewModel {
    public var tasks: [TaskItem] = []
    
    public init() {}
    
    public func toggleTask(id: UUID) {
        if let index = tasks.firstIndex(where: { $0.id == id }) {
            let task = tasks[index]
            tasks[index] = TaskItem(id: task.id, title: task.title, isCompleted: !task.isCompleted)
        }
    }
}

// 3. Parent View (Owns layout and coordinates events)
public struct TaskListView: View {
    @State private var viewModel = TaskListViewModel()
    @State private var isFilterActive = false

    public var body: some View {
        NavigationStack {
            List(viewModel.tasks) { task in
                // Pass immutable value for display, and callback closure for actions
                TaskRowView(task: task) {
                    viewModel.toggleTask(id: task.id)
                }
            }
            .navigationTitle("Tasks")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Toggle("Filter", isOn: $isFilterActive) // Pass binding for edits
                }
            }
        }
    }
}

// 4. Child View (Reusable, display-only + action callback)
struct TaskRowView: View {
    let task: TaskItem // Display-only immutable
    let onToggle: () -> Void // Event callback

    var body: some View {
        HStack {
            Text(task.title)
                .strikethrough(task.isCompleted)
            Spacer()
            Button(action: onToggle) {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .foregroundStyle(task.isCompleted ? .green : .secondary)
            }
            .buttonStyle(.plain)
        }
    }
}
```

---

## 9. SwiftUI List Performance & Identity

To avoid layout churn, rendering lags, and state loss, lists and loop containers must use stable and unique identity.

### Guidelines
- **Always use `Identifiable` objects** in `ForEach` and `List` containers.
- **Never use `.indices` or `id: \.self` on mutable/dynamic arrays.** If items shift (inserts, deletes), index-based identity breaks SwiftUI's diffing engine, causing row churn and animation glitching.
- **Choose Container Wisely:** Use `List` for standard system features (selection, swipe-to-delete, refreshable). Use `ScrollView` + `LazyVStack` (with `LazyVStack` wrapping ONLY the repeating items) for fully custom layouts.

### Skeleton: Performant List with Stable Identity
```swift
import SwiftUI

public struct TelemetryNode: Identifiable, Sendable {
    public let id: String // Unique and stable identifier (e.g. device serial number)
    public let name: String
    public let signalStrength: Double
}

struct NodeMonitorView: View {
    let nodes: [TelemetryNode]

    var body: some View {
        // Correct: List bound to Identifiable elements
        List(nodes) { node in
            HStack {
                Text(node.name)
                Spacer()
                Text("\(Int(node.signalStrength * 100))%")
                    .foregroundStyle(node.signalStrength < 0.2 ? .red : .primary)
            }
        }
    }
}
```

---

## 10. SwiftUI Lifecycle-Scoped Concurrency

SwiftUI views should tie async tasks to their lifecycle using `.task` to automatically cancel active background tasks when the view disappears.

### Lifecycle Comparison
- **View-scoped loading:** Use `.task { await loadData() }`.
- **State-driven reload:** Use `.task(id: filterID) { await loadFilteredData() }`. Cancels the current task and restarts it when the ID changes.
- **Avoid:** `onAppear { Task { ... } }` since tasks spawned this way escape the view's lifecycle and will continue running in the background even if the user navigates away, leading to leaks and stale updates.

### Skeleton: Lifecycle-Scoped Async Task
```swift
import SwiftUI

struct LogMonitorView: View {
    let sourceURL: URL
    @State private var logs: [String] = []
    @State private var isRefreshing = false

    var body: some View {
        List(logs, id: \.self) { log in
            Text(log)
        }
        // Runs when view appears, automatically cancelled when view disappears
        .task {
            await fetchLogs()
        }
        // Automatically cancels and restarts if sourceURL changes
        .task(id: sourceURL) {
            await fetchLogs()
        }
    }

    private func fetchLogs() async {
        do {
            let (data, _) = try await URLSession.shared.data(from: sourceURL)
            if let decodedLogs = try? JSONDecoder().decode([String].self, from: data) {
                self.logs = decodedLogs
            }
        } catch {
            // Handle error or cancel
        }
    }
}
```

---

## 11. Modern SwiftUI API Migration Checklist

Prefer modern SwiftUI APIs to optimize performance and take advantage of advanced compiler checks.

### Legacy → Modern API Mapping

| Legacy Pattern | Modern Replacement (iOS 17+) | Notes / Rationale |
| :--- | :--- | :--- |
| `NavigationView` | `NavigationStack(path:)` | Decouples links from destinations; type-safe, value-driven routing. |
| `NavigationLink(destination:)` | `NavigationLink(value:)` + `.navigationDestination(for:)` | Prevents destination views from being eagerly instantiated before tap. |
| `foregroundColor(_:)` | `foregroundStyle(_:)` | Supports rich styles, gradients, semantic shapes, and system materials. |
| `accentColor(_:)` | `tint(_:)` | Localized view-scoped styling without global pollution. |
| `cornerRadius(_:)` | `clipShape(.rect(cornerRadius:))` | Standardized, shape-aware clipping with selective corner support. |
| `@StateObject` | `@State` with `@Observable` | No wrapper overhead; fields tracked automatically. |
| `@EnvironmentObject` | `@Environment(MyType.self)` | Strictly type-safe environment lookup. |
| `onChange(of: value) { val in }` | `onChange(of: value) { old, new in }` | Access both preceding and current states (iOS 17+). |
| `onAppear { Task { await work() } }` | `.task { await work() }` | Automates task cancellation when the view hierarchy is dismissed. |
| `UIScreen.main.bounds` | `containerRelativeFrame()` | Avoids hardcoded screen sizes; adapts properly to multi-window split views. |
| `.sheet(isPresented:)` | `.sheet(item:)` | Cleaner state-driven presentation flow. |

