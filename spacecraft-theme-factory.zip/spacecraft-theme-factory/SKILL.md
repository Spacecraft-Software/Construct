---
name: spacecraft-theme-factory
description: A specialized tool for generating high-quality Spacecraft Software-compliant themes for various IDEs, editors, and terminal environments. Use it when you need to extend Spacecraft Software support to a new platform.
license: GPL-3.0-or-later
maintainer: Mohamed Hammad <Mohamed.Hammad@SpacecraftSoftware.org>
website: https://Construct.SpacecraftSoftware.org/
---

# Spacecraft Software Theme Factory

**Maintainer:** Mohamed Hammad | **Contact:** [Mohamed.Hammad@SpacecraftSoftware.org](mailto:Mohamed.Hammad@SpacecraftSoftware.org)
**Copyright:** (C) 2026 Mohamed Hammad & Spacecraft Software | **License:** GPL-3.0-or-later
**Website:** [https://Construct.SpacecraftSoftware.org/](https://Construct.SpacecraftSoftware.org/)

> **Source of truth:** The Steelbore Standard (§11 Colour Palette, §12 Typography)
> and the `spacecraft-brand-guidelines` skill. Themes may not introduce
> colors, fonts, or naming outside what these sources define.

## Color Palette (WCAG AA Compliant against Void Navy)

All colors are verified for contrast **against the Void Navy (`#000027`)
background** — Molten Amber 7.64:1, Steel Blue 4.77:1, Radium Green 14.87:1,
Red Oxide 6.74:1, Liquid Coolant 14.74:1. All pass Level AA.

**This guarantee does not extend to token-on-token pairings.** Most palette
tokens paired with each other fall below the 3:1 floor (Molten Amber on Red
Oxide is 1.13:1; Radium Green on Liquid Coolant is 1.01:1). Never emit a theme
that places palette-colored text on a palette-colored fill unless you have
measured that specific pair at ≥4.5:1 (Standard §11).

| Token          | Hex       | RGB                | Role                          |
|----------------|-----------|--------------------|-------------------------------|
| Void Navy      | `#000027` | RGB(0, 0, 39)      | **Background / Canvas**       |
| Molten Amber   | `#D98E32` | RGB(217, 142, 50)  | Primary Text / Active Readout |
| Steel Blue     | `#4B7EB0` | RGB(75, 126, 176)  | Primary Accent / Structural   |
| Radium Green   | `#50FA7B` | RGB(80, 250, 123)  | Success / Safe Status         |
| Red Oxide      | `#FF5C5C` | RGB(255, 92, 92)   | Warning / Error Status        |
| Liquid Coolant | `#8BE9FD` | RGB(139, 233, 253) | Info / Links                  |

**`#000027` (Void Navy) is the mandatory background for ALL Spacecraft Software surfaces** —
documents, terminals, editor themes, application UIs. No alternative background is permitted.

## Typography

Only FOSS-licensed fonts are permitted. Acceptable licenses: OFL, Apache 2.0, Ubuntu Font License, CC0-1.0.

| Context        | Font              | License | Source       |
|----------------|-------------------|---------|--------------|
| Headings       | Share Tech Mono   | OFL     | Google Fonts |
| Body / Code    | Inconsolata       | OFL     | Google Fonts |
| Fallback       | monospace (system)| N/A     | System       |

Never use proprietary fonts. Outfit, Inter, Roboto, and similar non-OFL fonts are **not permitted**.

## Theme Generation Workflow

1. **Select a target platform** — VS Code, JetBrains, terminal emulator, Material UI app, etc.
2. **Standard Theme Naming:** Always define the theme under the name `Steelbore` (file/module named `steelbore` in snake_case) and map the §11 palette into the platform's theme registry.
3. **Avoid Hardcoding:** Bundle colors into a named theme/config structure rather than hardcoding hex literals. This ensures the theme is easily replaceable so that users can add or swap custom themes without modifying application logic.
4. **Map the §11 palette** into the platform's color-key schema, preserving
   role semantics — Molten Amber for primary text, Steel Blue for structural
   accent, Radium Green for success states, Red Oxide for errors, Liquid
   Coolant for info/links. Never invent new color names or shift hex codes.
5. **Apply the §12 typography** (Share Tech Mono headings, Inconsolata body)
   wherever the platform supports font selection.
6. **Emit the accessibility variants alongside the default** (Standard §11.1.1)
   whenever the target platform supports more than one theme: `steelbore`
   (default, canonical palette), `steelbore-high-contrast` (`accent` →
   `#7FAEDC`, `error` → `#FF8080`; the other four tokens verbatim — every token
   ≥7:1 on Void Navy), and `steelbore-mono` (4-bit ANSI, deferring to the
   user's terminal palette). `steelbore` remains the sole default; the variants
   are additive siblings and never replace it. Void Navy stays the background
   in all three.
7. **Verify WCAG 2.2 AA contrast** against Void Navy for every color pair
   before shipping.
8. **Emit the platform's native config format** (JSON, XML, TOML, ini) with
   all hex codes verbatim from the canonical table.

## Output Targets

- **IDEs / editors**: VS Code, JetBrains, Helix, Zed, Neovim
- **Terminal emulators**: Kitty, Alacritty, WezTerm, Foot
- **Material Design GUI applications**
- **Document formats** (DOCX, PDF): force `#000027` page background and ISO
  A4 (210 × 297 mm) page size; apply palette text colors per
  `spacecraft-document-format`.

## Validation Checklist

Before shipping any generated theme:

- All hex codes match §11 verbatim — no variants, no near-matches.
- All fonts are FOSS-licensed and listed in §12.
- Every foreground token against Void Navy passes WCAG 2.2 Level AA. (Scope
  the claim precisely — token-on-token pairings are *not* covered and mostly
  fail; see the palette note above.)
- No generated theme places palette-colored text on a palette-colored fill
  without a measured ≥4.5:1 ratio for that specific pair.
- Where the platform supports multiple themes, `steelbore-high-contrast` and
  `steelbore-mono` are emitted alongside `steelbore`, and `steelbore` is still
  the default.
- Output references only `spacecraft-brand-guidelines` (lowercase) for
  upstream brand context; no claims of `/themes`, `/scripts`, or
  `/templates` subdirectories (this skill ships as `SKILL.md` only).

*— Built by Spacecraft Software —*
