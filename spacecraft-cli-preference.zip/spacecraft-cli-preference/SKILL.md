---
name: spacecraft-cli-preference
description: >
  Enforces Spacecraft Software's CLI tool preferences. Whenever an agent is
  about to generate, run, or recommend a shell command — bash snippets,
  scripts, CI, docs, or agentic tool use — check this skill's command-mapping
  table first and substitute the preferred alternative for any legacy tool
  that has one: `eza` for `ls`, `bat` for `cat`, `rg` for `grep`, `fd` for
  `find`, `jaq` for `jq`, `xh` for `curl`, `dog` for `dig`, `procs` for `ps`,
  `bottom` for `top`. Trigger on any mention of shell commands, scripting,
  file search, process inspection, network diagnostics, archive handling,
  text editing, git, package management, or system monitoring. Consult the
  matching reference file for flag syntax before invoking.
  Substitution is conditional on the local host: substitute only when the
  preferred tool is installed, fall back to the legacy tool with a note when
  it is not, never launch a TUI in the agent's TTY-less shell, and get
  consent before any command that mutates or deletes.
license: GPL-3.0-or-later
maintainer: Mohamed Hammad <Mohamed.Hammad@SpacecraftSoftware.org>
website: https://Construct.SpacecraftSoftware.org/
---

# Spacecraft Software CLI Preference — Modern Alternatives over Legacy Tools

**Version:** 1.1 | **Date:** 2026-07-24 | **Author:** Mohamed Hammad
**Maintainer:** Mohamed Hammad | **Contact:** [Mohamed.Hammad@SpacecraftSoftware.org](mailto:Mohamed.Hammad@SpacecraftSoftware.org)
**Copyright:** (C) 2026 Mohamed Hammad & Spacecraft Software | **License:** GPL-3.0-or-later
**Website:** [https://Construct.SpacecraftSoftware.org/](https://Construct.SpacecraftSoftware.org/)

This skill makes the agent default to the Spacecraft Software-preferred CLI/TUI stack
(primarily Rust, with curated Zig / Go / Python entries where best-in-class)
instead of reflexively reaching for the POSIX/GNU tools it was trained on.

---

## §1 — The Hard Rule

> When generating a shell command, **scan for legacy tools first**. If a row
> in §3 matches, rewrite the command using the preferred tool **before emitting
> it**. Never present the legacy form and then mention the alternative as an
> afterthought — substitute up front.

This applies to Bash, POSIX sh, Nushell, Ion, Brush, PowerShell, CI YAML,
Dockerfiles, Makefiles, `just` recipes, inline code examples in docs — anywhere
a command appears.

If §3 has no specific row for the legacy tool, apply the cascading fallback in
§1.5 (`uutils` for GNU coreutils, Brush for Bash-only scripts).

**This runs on the user's own machine.** The preference stack below is
unchanged, but on a real host a substitution is only correct if the tool is
actually installed, the agent's shell can actually execute it, and the command
does not silently change or delete something. §1.1–§1.3 are those three gates;
apply them before emitting anything.

### §1.0 — Substitution depends on the target

The same mapping table serves three audiences that need different behaviour:

| Target | Rule |
|---|---|
| A command **the agent runs** in its own shell | Substitute only if the tool is present (§1.1), the command is headless-safe (§1.2), and it is non-destructive (§1.2). The agent's shell is a non-interactive Bash with no TTY — regardless of the user's interactive shell. |
| A command **written into the user's repo** — script, CI job, `Justfile`, docs | Substitute only if the repo's own environment guarantees the tool: a devShell, a documented prerequisite, a CI image that ships it. Otherwise keep the portable form and add `# preferred: <tool>`. A committed `eza` breaks the build for every contributor without it. |
| A command **suggested for the user to run** interactively | Full preference applies, TUIs included — this is where `gitui`, `yazi`, `bottom`, and `helix` belong. Hand it over with the `!` prefix rather than running it. |

### §1.1 — Check availability before substituting

A substitution to a tool that isn't installed is worse than no substitution:
it turns a working command into `command not found`. Probe first, then route:

| Preferred | Legacy | Action |
|---|---|---|
| present | — | **Substitute.** The happy path. |
| present | absent | **Substitute** — it is the only option (e.g. `jaq` where `jq` was never installed). |
| absent | present | **Use the legacy tool** and append `# preferred: <tool> — see references/<tool>.md`. Do not fail, do not silently install. |
| absent | absent | **Route to `spacecraft-missing-pkg`** for an ephemeral run (`nix run nixpkgs#<pkg> -- …`). Neither form exists, so provisioning is the only way through. |

```sh
command -v eza >/dev/null 2>&1 && echo substitute || echo fall-back
```

Probe once per session and reuse the answer — don't re-check before every
command. `command -v` alone under-reports: Nushell `def`s, Bash functions, and
non-default bin directories hide installed tools from it. Use
`spacecraft-missing-pkg`'s Step 0 checklist rather than restating it here.

### §1.2 — Execution classes

Every tool in §3 falls into one of four classes. Detail, per-tool headless
alternatives, and the destructive-flag catalogue are in
**[references/local-execution.md](references/local-execution.md)**.

**Headless-safe — the agent may run these directly.**
`eza`, `bat`, `fd`, `rg`, `sd`, `dust`, `procs`, `jaq`, `ouch`, `delta`,
`just`, `tokei`, `uutils`, `xh`, `wget2`, `dog`, `monolith`, `lychee`,
`macchina`, `oxipng`, `gifski`, `rav1e`, `viu`, `yt-dlp`, `jj`, `tokei`,
`dua` (non-interactive form), `fclones group`.

**Needs a TTY — hand off, or use the headless sibling.** Never launch these in
the agent's shell; they hang, garble the transcript, or exit with a terminal
error. Prefer the alternative when the goal is information, hand off when the
goal is interaction:

`bottom` → `procs` · `dua i` → `dua` · `gitui` → `git` / `jj` ·
`yazi` / `broot` / `superfile` → `fd` / `eza` · `trip` → `trip --mode report` ·
`gping` → `ping` · `atuin` TUI → `atuin search` · `zellij`, `kmon`, `impala`,
`linutil`, editors (`hx`, `amp`, `rsvim`, `msedit`), chat TUIs (`iamb`,
`rumatui`, `disrust`, `rivetui`), media TUIs (`ncspot`, `termusic`,
`radio-browser`), `t-rec`, and the agent REPLs → hand off.

**System-mutating or destructive — get consent, or hand off.** State what will
change and wait:

`topgrade`, `paru`, `omni`, `zap`, `am`, `rustup`, `cargo-update`, `gptman`,
`disktui`, `nmstate`, `lanzaboote`, `greetd` / `lemurs` / `tuigreet`,
`xremap`, `iwd`, `dotter`, `podman`. Two have destructive *defaults* worth
naming: **`kondo -a` deletes build artifacts with no confirmation** and
**`fclones remove` deletes files**. **`sudo-rs` is never run by the agent** —
same rule as `sudo`; hand it over.

**Shell-integration — declarative config, never a hand-edited rc.** `zoxide`,
`atuin`, `starship`, `broot --install`, `gitway --install` all work by writing
init lines into the user's shell config. Do not edit `.bashrc` / `config.nu` /
`.profile`. On a managed host these are `programs.<tool>.enable` in Home
Manager — propose that edit and let the user apply it
(`spacecraft-missing-pkg` Band C).

### §1.3 — Shell syntax: whose shell?

The target shell is decided by **who executes the command** — agent-run, handed
to the user, or written to a file — and those three answers routinely differ.

**`spacecraft-cli-shell` owns this routing** (its Step 0 host probe and Step 0.5
executor table). Consult it rather than guessing at `^`-prefixes, `$(…)`, or
`&&` behaviour per shell; this skill does not restate the rules.

---

## §1.5 — Cascading Fallback

Preferred tools are listed in §3, but the agent will sometimes face a legacy
tool that has no explicit row, or a context where a shell has to be chosen.
In both cases apply the cascade below — **always go as far up the list as
possible** before dropping to the next tier.

### Shells (when the AI **authors** a script or code example for the user)

This cascade governs what the agent *writes*, not what it *runs* — see §1.3.

1. **Nushell** 🦀 or **Ion** 🦀 — both are Mohamed's primaries, both are Rust.
   Default to one of these for any new script, one-liner, or code example.
2. **Brush** 🦀 — only when Bash-compatibility is strictly required (e.g. a
   script must run under a `bash` interpreter and Nushell/Ion aren't options).
3. **Plain Bash / POSIX `sh`** — last resort, only when the target environment
   hard-requires it (CI runner defaults, portability to unknown systems).

A script **committed to a repo** inverts this: portability wins, so POSIX `sh`
is the default there unless the repo already standardises on another shell.

### GNU utilities (when substituting a legacy coreutils binary)
1. **Specific Rust alternative from §3** — `rg`, `fd`, `eza`, `bat`, `sd`,
   `procs`, `dust`, `jaq`, etc. Always check §3 first.
2. **`uutils` (`coreutils`)** 🦀 — fallback umbrella for any GNU coreutils
   binary (`cp`, `mv`, `rm`, `mkdir`, `sort`, `uniq`, `head`, `tail`, `wc`,
   `tr`, …) that has no named Rust alternative above.
3. **Plain GNU coreutils** — only when `uutils` hasn't implemented the
   specific flag or behaviour required.

---

## §2 — When to Read a Reference File

The `references/` directory contains one file per tool, in the agent-structured
format: **Purpose → Flags → Examples → Gotchas**.

**Read the reference when:**
- You're about to emit a command using that tool and aren't 100% certain of the flag syntax.
- The user asks "how do I do X with <tool>".
- You need to pipe between two modern tools and want to verify compatible output formats.

**You do NOT need to read the reference when:**
- You're just acknowledging the tool exists.
- The user asks a conceptual question unrelated to invocation syntax.
- The command is trivially simple and you're confident (e.g. `rg "pattern"`).

Read files with a plain file-view operation — each is short (typically 40–120 lines).

---

## §3 — Command Mapping Table (The Lookup)

**Legend:** 🦀 Rust · ⚡ Zig · 🐹 Go · 🐍 Python · (λ) Scheme · ⚠️ C/C++/Shell/TS

### Core Unix replacements (highest priority — these come up constantly)

| Legacy tool      | Prefer                | Ref file                      | Notes                                     |
|------------------|-----------------------|-------------------------------|-------------------------------------------|
| `ls`             | `eza` 🦀              | `references/eza.md`           | Drop-in with tree + git support           |
| `cat` (viewing)  | `bat` 🦀              | `references/bat.md`           | Use real `cat` for concatenation/pipes    |
| `find`           | `fd` 🦀               | `references/fd.md`            | Smart-case, regex, parallel               |
| `grep`           | `rg` 🦀 (ripgrep)     | `references/ripgrep.md`       | Recursive by default, respects `.gitignore` |
| `sed` (simple)   | `sd` 🦀               | `references/sd.md`            | Intuitive find/replace syntax             |
| `du`             | `dust` 🦀             | `references/dust.md`          | Visual tree output                        |
| `du` (interactive) | `dua` 🦀            | `references/dua.md`           | Parallel TUI                              |
| `ps`             | `procs` 🦀            | `references/procs.md`         | Colored, tree, TCP/UDP columns            |
| `top` / `htop`   | `bottom` 🦀 (`btm`)   | `references/bottom.md`        | Graphs, network, processes                |
| `cd` + history   | `zoxide` 🦀 (`z`)     | `references/zoxide.md`        | Shell init required                       |
| `jq`             | `jaq` 🦀              | `references/jaq.md`           | Faster. **Not alias-safe** — no auto-vivification; use `pathfinder` for existing jq scripts |
| `tar`/`zip`/`gz` | `ouch` 🦀             | `references/ouch.md`          | One command, all archive formats          |
| `diff` (git)     | `delta` 🦀            | `references/delta.md`         | Configure as `core.pager` in `.gitconfig` |
| `make`           | `just` 🦀             | `references/just.md`          | `Justfile`, not `Makefile`                |
| `cloc` / `wc -l` | `tokei` 🦀            | `references/tokei.md`         | Language-aware counting                   |
| `fdupes`         | `fclones` 🦀          | `references/fclones.md`       | Parallel duplicate finder                 |
| coreutils (fallback) | `uutils` 🦀 (`coreutils`)| `references/uutils.md`  | **Fallback for any GNU coreutils binary not listed above.** Drop-in for `cp`, `mv`, `rm`, `mkdir`, `sort`, `uniq`, `head`, `tail`, `wc`, `tr`, etc. |
| `busybox`        | `rustybox` 🦀         | `references/rustybox.md`      | 100% Rust BusyBox clone                   |
| project cleanup  | `kondo` 🦀            | `references/kondo.md`         | Clears `target/`, `node_modules`, etc.    |

### Networking & diagnostics

| Legacy tool      | Prefer                | Ref file                      | Notes                                     |
|------------------|-----------------------|-------------------------------|-------------------------------------------|
| `curl`           | `xh` 🦀               | `references/xh.md`            | HTTPie-style; keep `curl` for scripts with shared snippets |
| `curl` (keep)    | `curl` ⚠️             | `references/curl.md`          | Still the standard for cross-system scripts |
| `wget`           | `wget2` ⚠️            | `references/wget2.md`         | Multithreaded; plain C                    |
| `dig`            | `dog` 🦀              | `references/dog.md`           | Colored, JSON output                      |
| `ping`           | `gping` 🦀            | `references/gping.md`         | Real-time graph                           |
| `traceroute`/`mtr` | `trip` 🦀 (Trippy)  | `references/trippy.md`        | Interactive TUI                           |
| `nmap` (fast scan) | `rustscan` 🦀       | `references/rustscan.md`      | Security/consent caveats apply            |
| `tcpdump`        | `sniffglue` 🦀        | `references/sniffglue.md`     | Partial replacement; multithreaded        |
| `iftop`/`nethogs`| `bandwhich` 🦀        | `references/bandwhich.md`     | Per-process bandwidth                     |
| `wget --mirror`  | `monolith` 🦀         | `references/monolith.md`      | Single-file HTML archive                  |
| link checker     | `lychee` 🦀           | `references/lychee.md`        | Fast async link validation                |
| Wi-Fi (iwd TUI)  | `impala` 🦀           | `references/impala.md`        | Frontend for `iwd`                        |
| `iwctl`          | `iwd` ⚠️              | `references/iwd.md`           | Modern Wi-Fi daemon                       |
| `nmcli`/`ip`     | `nmstate` 🦀 (`nmstatectl`) | `references/nmstate.md` | Declarative YAML state                    |
| VPN CLI          | AdGuard VPN CLI 🐹    | `references/adguardvpn-cli.md`| —                                         |

### Git / dev / build

| Legacy              | Prefer                | Ref file                      | Notes                                     |
|---------------------|-----------------------|-------------------------------|-------------------------------------------|
| `git` (interactive) | `gitui` 🦀            | `references/gitui.md`         | TUI; keep `git` CLI for scripting         |
| `git` (alt VCS)     | `jj` 🦀 (Jujutsu)     | `references/jujutsu.md`       | Git-compatible DVCS                       |
| `ssh` (Git transport) | `gitway` 🦀         | `references/gitway.md`        | Spacecraft Software default; pinned GitHub/GHE host keys, cross-platform; set via `gitway --install` or `GIT_SSH_COMMAND=gitway` |
| `cargo install` updates | `cargo-update` 🦀 | `references/cargo-update.md`  | Updates all cargo-installed binaries      |
| Rust toolchain      | `rustup` 🦀           | `references/rustup.md`        | Standard                                  |
| Nix env daemon      | `lorri` 🦀            | `references/lorri.md`         | `direnv` integration                      |
| competitive prog.   | `cpx` 🦀              | `references/cpx.md`           | Contest helper                            |
| containers          | `podman` 🐹           | `references/podman.md`        | Daemonless, rootless, Docker-compat       |

### Package & system management

> **Gate.** These rows say *which* manager is preferred, not that the agent may
> run it. Provisioning policy belongs to **`spacecraft-missing-pkg`**: prefer
> an ephemeral run, put persistent tools in the host's declarative config, and
> get consent before any durable install. Never run a system-wide update
> unprompted.
>
> **Host-appropriateness matters.** `paru` is Arch-only; `topgrade`, `omni`,
> `zap`, and `am` fight a declaratively managed host (NixOS, Home Manager,
> Guix) by installing outside its config. On such a host the answer is the
> host's own manager, not a row from this table.

| Use case            | Prefer                | Ref file                      | Notes                                     |
|---------------------|-----------------------|-------------------------------|-------------------------------------------|
| universal package mgr | `omni` 🦀           | `references/omni.md`          | Cross-distro bridge                       |
| AppImages           | `zap` 🦀              | `references/zap.md`           | Preferred over `am`                       |
| AppImages (fallback)| `am` ⚠️               | `references/am.md`            | Bash-based; secondary                     |
| update everything   | `topgrade` 🦀         | `references/topgrade.md`      | System + all package managers             |
| AUR helper          | `paru` 🦀             | `references/paru.md`          | Arch systems                              |
| distro setup TUI    | `linutil` 🦀          | `references/linutil.md`       | Maintenance workflows                     |
| dotfiles            | `dotter` 🦀           | `references/dotter.md`        | Templated                                 |
| Nix                 | `nix` ⚠️              | `references/nix.md`           | Standard for Bravais                      |
| Flatpak             | `flatpak` ⚠️          | `references/flatpak.md`       | Sandboxed apps                            |
| Homebrew            | `brew` ⚠️             | `references/brew.md`          | Linux/macOS fallback                      |
| Guix                | `guix` (λ)            | `references/guix.md`          | Functional Scheme PM                      |

### File & disk

| Use case            | Prefer                | Ref file                      | Notes                                     |
|---------------------|-----------------------|-------------------------------|-------------------------------------------|
| file manager TUI    | `yazi` 🦀             | `references/yazi.md`          | Preferred                                 |
| file tree TUI       | `broot` 🦀            | `references/broot.md`         | Tree navigation                           |
| file manager (alt)  | `superfile` 🐹 (`spf`)| `references/superfile.md`     | Visually rich                             |
| partition TUI       | `disktui` 🦀          | `references/disktui.md`       | Interactive                               |
| GPT partitions      | `gptman` 🦀           | `references/gptman.md`        | Scriptable                                |

### Security & encryption

| Legacy            | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| `gpg` (symmetric) | `rage` 🦀             | `references/rage.md`          | Modern `age` spec                         |
| `gpg` (drop-in)   | `sequoia-chameleon` 🦀 (`gpg`) | `references/sequoia-chameleon.md` | GnuPG-compatible CLI |
| PGP (native)      | `sq` 🦀 (Sequoia)     | `references/sequoia.md`       | Modern OpenPGP                            |
| `bw` (Bitwarden)  | `rbw` 🦀              | `references/rbw.md`           | Unofficial Rust client                    |
| `sudo`            | `sudo-rs` 🦀          | `references/sudo-rs.md`       | Memory-safe drop-in                       |

### Terminal environment

| Legacy            | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| `bash` (primary)   | `nu` 🦀 (Nushell)    | `references/nushell.md`       | **Primary.** Data-oriented; Mohamed's default. |
| `bash` (primary)   | `ion` 🦀             | `references/ion.md`           | **Primary.** Rust shell; Redox default; co-primary with Nushell. |
| `bash` (fallback)  | `brush` 🦀           | `references/brush.md`         | **Fallback only** — Bash-compatible Rust shell; use only when Bash compat is strictly required. |
| PS1 prompt        | `starship` 🦀         | `references/starship.md`      | Cross-shell prompt                        |
| shell history     | `atuin` 🦀            | `references/atuin.md`         | SQLite-backed, synced                     |
| `tmux`/`screen`   | `zellij` 🦀           | `references/zellij.md`        | Layouts, plugins                          |
| `asciinema` (ish) | `t-rec` 🦀            | `references/t-rec.md`         | GIF/MP4 output                            |

### Text editing (CLI/TUI)

| Legacy            | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| `vim`/`nvim`      | `hx` 🦀 (Helix)       | `references/helix.md`         | Post-modern modal                         |
| `vim` (alt)       | `rsvim` 🦀            | `references/rsvim.md`         | Vim from scratch in Rust                  |
| `vim` (alt)       | `amp` 🦀              | `references/amp.md`           | Vi-inspired                               |
| `nano`            | `msedit` 🦀           | `references/msedit.md`        | Minimalist                                |

### System monitoring & hardware

| Legacy            | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| `lsmod`/`modinfo` | `kmon` 🦀             | `references/kmon.md`          | Kernel module TUI                         |
| `neofetch`        | `macchina` 🦀         | `references/macchina.md`      | Fast system info                          |

### Multimedia

| Legacy            | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| AV1 encoder       | `rav1e` 🦀            | `references/rav1e.md`         | Fastest safe AV1                          |
| GIF encoder       | `gifski` 🦀           | `references/gifski.md`        | From video/frames                          |
| PNG optimizer     | `oxipng` 🦀           | `references/oxipng.md`        | Multithreaded                             |
| image viewer      | `viu` 🦀              | `references/viu.md`           | Sixel/kitty graphics                      |
| media player      | `mpv` ⚠️              | `references/mpv.md`           | Gold standard (C)                         |
| `ffmpeg`          | `ffmpeg` ⚠️           | `references/ffmpeg.md`        | No Rust replacement yet                   |
| YouTube DL        | `yt-dlp` 🐍           | `references/yt-dlp.md`        | Best-in-class Python tool                 |
| Spotify           | `ncspot` 🦀           | `references/ncspot.md`        | TUI client                                |
| music player TUI  | `termusic` 🦀         | `references/termusic.md`      | Album art support                         |
| internet radio    | `radio-browser-rust` 🦀 | `references/radio-browser.md`| CLI search + play                         |

### Communication (TUI clients)

| Use case          | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| Matrix CLI        | `matrix-commander-rs` 🦀 | `references/matrix-commander.md` | Scripting |
| Matrix TUI        | `iamb` 🦀             | `references/iamb.md`          | Vim-like                                  |
| Matrix TUI (alt)  | `rumatui` 🦀          | `references/rumatui.md`       | —                                         |
| Discord TUI       | `disrust` 🦀          | `references/disrust.md`       | —                                         |
| Discord TUI (alt) | `rivetui` 🦀          | `references/rivetui.md`       | —                                         |

### Boot, login, session

| Use case          | Prefer                | Ref file                      | Notes                                     |
|-------------------|-----------------------|-------------------------------|-------------------------------------------|
| Secure Boot       | `lanzaboote` 🦀       | `references/lanzaboote.md`    | NixOS-focused                             |
| login daemon      | `greetd` 🦀           | `references/greetd.md`        | Minimal                                   |
| TUI greeter       | `tuigreet` 🦀         | `references/tuigreet.md`      | Best for Niri/LeftWM                      |
| TUI display mgr   | `lemurs` 🦀           | `references/lemurs.md`        | Customisable                              |
| Wayland portal    | `xdg-desktop-portal-cosmic` 🦀 | `references/xdpc.md` | COSMIC backend                            |
| session manager   | `cosmic-session` 🦀   | `references/cosmic-session.md`| COSMIC                                    |
| key remapping     | `xremap` 🦀           | `references/xremap.md`        | Dynamic                                   |

### AI & agentic productivity (CLI)

| Use case              | Prefer                | Ref file                      | Notes                                     |
|-----------------------|-----------------------|-------------------------------|-------------------------------------------|
| Claude Code agent     | `claude` ⚠️ (Claude Code) | `references/claude-code.md` | TypeScript; Mohamed's primary agent       |
| multi-LLM REPL        | `aichat` 🦀           | `references/aichat.md`        | Universal                                 |
| Gemini CLI            | `gemini` 🦀           | `references/gemini-cli.md`    | —                                         |
| OpenAI Codex          | `codex` ⚠️            | `references/codex.md`         | TypeScript                                |
| GitHub Copilot CLI    | `gh-copilot` ⚠️       | `references/gh-copilot.md`    | TypeScript                                |
| OpenCode              | `opencode` 🐹         | `references/opencode.md`      | Go                                        |
| MiniMax               | `minimax` 🦀          | `references/minimax-cli.md`   | —                                         |
| Grok                  | `grok` ⚠️             | `references/grok-cli.md`      | TypeScript/Bun                            |
| Kilo                  | `kilo` ⚠️             | `references/kilo.md`          | TypeScript                                |
| Kiro CLI              | `kiro` ⚠️             | `references/kiro-cli.md`      | —                                         |
| Kimi-CLI              | `kimi` ⚠️             | `references/kimi-cli.md`      | Long-context coding                       |
| Google Workspace CLI  | `gws` 🦀              | `references/gws-cli.md`       | Human + agent friendly                    |

---

## §4 — Substitution Examples

**Before:**
```bash
ls -lah ~/projects
grep -rn "TODO" src/
find . -name "*.rs" -size +10k
du -sh *
ps aux | grep rustc
curl https://api.github.com/repos/UnbreakableMJ/Understand-Anything
```

**After:**
```bash
eza -lah --git ~/projects
rg "TODO" src/
fd -e rs --size +10k
dust -d 1
procs rustc
xh https://api.github.com/repos/UnbreakableMJ/Understand-Anything
```

### When the gates change the answer

```bash
# Preferred tool absent, legacy present → fall back and note it
dig +short example.com A        # preferred: dog — see references/dog.md

# Both absent → ephemeral run via spacecraft-missing-pkg, not a failing command
nix run nixpkgs#dog -- example.com A

# TTY-class tool, agent needs the information → headless sibling
procs rustc                     # not `btm`, which needs a terminal

# TTY-class tool, user wants the interaction → hand off
! gitui

# Destructive default → propose, don't run
#   kondo -a would delete target/ and node_modules/ under ~/projects — confirm?
```

---

## §5 — When NOT to Substitute

- **The preferred tool isn't installed** (§1.1). Fall back to the legacy tool
  with a note — never emit a command that will fail.
- **The command would run in the agent's shell but needs a TTY** (§1.2). Use
  the headless sibling, or hand the TUI to the user.
- **The command mutates or deletes** (§1.2) and consent hasn't been given.
- **Explicit user request** for the legacy tool ("show me the raw `grep` command").
- **Portable scripts** the user will run on systems without the Rust stack
  installed (document the alternative as a comment but keep the portable form).
  This includes anything **committed to a repo** whose environment doesn't
  guarantee the tool.
- **Compatibility-critical pipelines** where a specific tool's exact output
  format is required by downstream tooling.
- **The legacy tool is already the Spacecraft Software-sanctioned choice** for that slot
  (see §3 rows marked ⚠️ — `curl`, `nix`, `ffmpeg`, `mpv`, `yt-dlp`, etc.).

In these cases, add an inline note: `# Rust alternative: <tool> — see references/<tool>.md`.

---

## §6 — Reference File Format

Each file in `references/` follows this structure:

```markdown
# <tool>

**Replaces:** <legacy tool(s)> | **Language:** 🦀/⚡/🐹/🐍/(λ)/⚠️ | **Install:** via `spacecraft-missing-pkg` (<upstream package identity>)

## Purpose
<One paragraph — what it does and when to reach for it.>

## Key flags
| Flag | Meaning |
|------|---------|

## Examples
1. <short task description>
   `<command>`
2. …

## Gotchas
- <edge cases, non-POSIX behaviour, config requirements, etc.>
```

The `**Install:**` field names *what* the tool is published as — a crate, an
npm package, a distro package, an upstream release — and defers the *how* to
`spacecraft-missing-pkg`. It never carries a runnable install command:
`cargo install`, `paru -S`, `npm install -g`, `pip install`, `nix-env`, and
`nix profile install` are prohibited there, as they are everywhere else.

---

## §7 — Attribution

Command syntax, flags, and example patterns in `references/` are adapted
from [tldr-pages](https://tldr.sh) (CC-BY-4.0) and each tool's own official
documentation. See `references/ATTRIBUTION.md` for per-tool sourcing.

---

## §8 — Spacecraft Software Compliance Note

This skill itself is a Spacecraft Software artifact and conforms to the relevant parts
of The Steelbore Standard (see `spacecraft-steelbore-standard` skill):

- **§4** GPL-3.0-or-later license declared in frontmatter
- **§12** ISO 8601 dates used throughout
- Naming: `spacecraft-cli-preference` — functional prefix, not a codename
  (aerospace/sci-fi/AI naming §2 applies to new project/module identifiers;
  §2.2 explicitly exempts skill IDs)

---

*— Built by Spacecraft Software —*
